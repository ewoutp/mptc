/*** (C) 1994-> Wim Lewis and others (Credits file)
 *** this is a simple program to drive the lines of the PIC programmer
 *** Not very important when the programmer works, just a nice
 *** debugging tool!
 ***/

#include <string.h>
#define EXTERN
#include "prog84.h"
#include "progutil.h"

extern int prog_w, read_w; /* dummy, used in progutil.h*/

void doSimple(name, bit, buf)
     const char *name;
     int bit;
     char *buf;
{
    int num = atoi(buf);
    if (bit < 0) {
      printf("err: %s bit not defined in cfg file\n", name);
      return;
    }
    lpb_write(&lpb, bit, num?1:0);
    printf("%s O%s\n", name, num?"N":"FF");
    lpb_flush(&lpb);
}

#if 0
static verf=0;
void ClockPulses(int clks, char *s) {
	int d;
        if (verf) fprintf(stdout,"%s{",s);
	while (clks-- >=0) {
	  if ((!verf) && (clks %10 == 1)) fputc('.',stdout);
	  SET(clock,1); FLUSH; 
	  d=GET(data_f); 
	  if (verf) fprintf(stdout,"%d",d);
	  SET(clock,0); FLUSH; 
	}
        if (verf) fprintf(stdout,"}\n");
}


int GetAck(int dcmp) {
  int d,cnt=0;
  SET(clock,0); FLUSH; 
  if (verf) fprintf(stdout,"(");
  do {
	SET(clock,1); FLUSH; 
	d=GET(data_f); cnt++;
	if (verf) fprintf(stdout,"%d",d);
	SET(clock,0); FLUSH; 
  } while (d != dcmp) ;
  if (verf) fprintf(stdout,")\n");
 return cnt;
}

void SendData(int val, int contdata, int nclks) {
  int cnt;  /* nclcks = 28 */
  for (cnt=0; cnt<=7; cnt++) {
	  ClockPulses(nclks,"");
	  if (verf) printf("W%d",val&1);
	  SET(data, val & 1); val >>= 1; FLUSH;
  }
  ClockPulses(nclks-4,"");  /* 24 */
  if (verf) printf("END=%d", contdata==0);
  SET(data, contdata == 0); FLUSH;

}

int RecvData(int nclks) {
  int d=0,mask=1;
  int cnt;
  for (cnt=0; cnt<=7; cnt++) {
    d |= GET(data_f)>0 ? mask : 0;
    if (verf) printf("R%d",d&mask ? 1:0);
   /* fprintf(stdout,".%x-%x.",d,mask); */
    mask <<=1;
    ClockPulses(nclks,"");
  }
  return d;
}

#endif


void ClockPulsesV(int clks, char *s) {
	int d;
        if (verbose>1) fprintf(stdout,"%s{",s);
	while (clks-- >=0) {
	  if ((verbose==1) && (clks %10 == 1)) fputc('.',stdout);
	  SET(clock,1); FLUSH; 
	  d=GET(data_f); 
	  if (verbose) fprintf(stdout,"%d",d);
	  SET(clock,0); FLUSH; 
	}
        if (verbose>1) fprintf(stdout,"}\n");
}


int RecvDataMM2(int nclks) {
 /* nclks should be 380-410 */
  int d=0,mask=0x200;
  int cnt;

  SET(data,1); SET(clock,0); FLUSH;
  cnt=GetAck(0);
  if (verbose>1) fprintf(stdout,"got d=0, clock_cnt=%d\n",cnt);
  ClockPulses(50,""); /* wait a bit for input  to stabilize */
  for (cnt=0; cnt<=9; cnt++) {
    d |= GET(data_f)>0 ? 0 : mask;
    if (verbose>2) printf("R%d",d&mask ? 1:0);
   /* fprintf(stdout,".%x-%x.",d,mask); */
    mask >>=1;
    ClockPulses(nclks,"");
  }
  return (d&0x1ff)>>1;
}
void TxDataMM2(int val, int nclks) {
  /* mm2 has STD_DELAY set to approx 394-400 clocks, means slower
     bps than specified  (~ 9015 bps), or 4MHz clock @ 10070 bps */
  /* nclks should be 397*/
  int d,mask=0x200;
  int cnt;
  
  SET(data,1); SET(clock,0); FLUSH;

  ClockPulses(120,""); /* adequate delay ? to let mm2 code run */
  d= (~(val<<1) | 1) & 0x01ff;
  if (verbose) fprintf(stdout,"send val=%02x (%03x) ",val,d);
  
  /* send startbit(0), d7..d0, and stopbit(1) : */ 
  for (cnt=0; cnt<=9; cnt++) {
    if (verbose>1) fprintf(stdout," %02x ",d & mask);
    else if (verbose) fprintf(stdout," %d ", (d & mask)? 1 : 0);
    SET(data, (d & mask)? 1 : 0);
    mask >>=1;
    ClockPulses(nclks,"");
  }
  SET(data,1); SET(clock,0); FLUSH;
  ClockPulses(nclks*2,""); /* stop bit delay */
  if (verbose) printf("\n");
}

void help() {
  printf("\n*** simple jig mode. enter:\n"
         "  p0 or p1  to turn power off or on\n"
         "  m0 or m1  to set MCLR low or high\n"
	 "  c0 or c1  to set the clock input\n"
         "  cp        clock puls (010)\n"
	 "  cack  [1|0]  send clock pulses until RB7 goes 1/0\n"
	 "  cackr [1|0]  -\"- + read input\n"
	 "  ewr A N1 [N2 ...]   write byte N1, N2,...  in addr A,A+1,...\n"
	 "  erd A     read  byte from addr A\n"
	 "  nrd       read  next byte\n"
	 "  ewrs A    write single byte B \n"
	 "  tx N1 [N2 ...] mm2-transmit bytes\n"
	 "  rx N      receive N bytes\n"
	 "  d0 or d1  to set the data input\n"
	 "  ver       cycle verbose flag (0->1->2->3->0)\n"
	 "  r         to read the current clock & data sense lines\n");
  if (chip_p->type==PIC) 
	printf(
         "  d c       to clock c bits of d, lsb first\n"
	 "  .conf     to load configuration\n"
	 "  .read     to read program memory\n"
	 "  .next     to advance address\n"
	 "  .prog n   to program current cell with n\n"
	 );
  else
	printf(
	 "  .ack       ack\n"
	 "  .stop      i2c_stop()\n"
	 "  .start     i2c_start()\n"
	 "  .read  N   read byte (ack=N)\n"
	 "  .write N   sendbyte(N)\n"
	 "  .ra N      read byte from address N\n"
	 "  .wa N  M   write byte M from address N\n"
	 );
  printf("  q          quit program (or EOF)\n"
	 "  h          this help\n");

}


void jig()
{
  char buf[256];
  int bits, num;
  int gaddr=0,delval=396;

  help();
  while(fgets(buf, 256, stdin)) {
    if(!*buf) break;

    if (*buf=='h') { help(); continue; }
    if (chip_p->type==PIC) {
      if (!strncmp(buf,".read",5)) {
	printf("read 0x%04x\n", genericRead(4));
	continue;
      }
      if (!strncmp(buf,".next",5)) {
	pipeBits(6,6);
	continue;
      }
      if (!strncmp(buf,".conf",5)) {
	genericWrite(0, 0); /* load prog. mem */
	printf("read 0x%04x\n", genericRead(4));
	continue;
      }
      if (!strncmp(buf,".prog",5)) {
	int d;
	sscanf(buf+5,"%i", &d);
	genericWrite(2, d); /* load prog. mem */
	pipeBits(8, 6);
	usleep(20000UL);
	continue;
      }
    } else {
      if (!strncmp(buf,".start",6)) {
	i2c_start(); continue;
      }
      if (!strncmp(buf,".stop",5)) {
	i2c_stop(); continue;
      }
      if (!strncmp(buf,".ack",4)) {
	int d=0;
	if (buf[4]=='1' || buf[5]=='1') d=1;
	printf("read 0x%04x\n", i2c_readbyte(d));
	continue;
      }
      if (!strncmp(buf,".ra",3)) {
	unsigned long adr;
	int dat;
	adr=strtoul(buf+3,NULL,0);
/*	i2c_start();
	i2c_sendbyte(0xa0 | ((adr>>7)&0x0e));
	i2c_sendbyte(adr & 0xff);
	i2c_start();
        i2c_sendbyte(0xa1);
        dat=i2c_readbyte(I2C_ACK);  send ACK */ 
	dat=i2c_read(adr); 
	i2c_stop();
	printf("read(0x%04x)=0x%04x\n", (int)adr, dat);
	continue;
      }
      if (!strncmp(buf,".wa",3)) {
	unsigned short adr,val;
	char *endp;
	adr= (unsigned short) strtoul(buf+3,&endp,0);
	val= (unsigned short) strtoul(endp+1,&endp,0);
	i2c_write(adr,val); 
	printf("write(0x%04x)=0x%04x\n", (int)adr, val);
	continue;
      }
      if (!strncmp(buf,".read",5)) {
	unsigned long d;
	d=strtoul(buf+5,NULL,0);
	printf("read(ack=0x%02lx)=0x%0x\n", d,i2c_readbyte((int)d));
	usleep(20000UL);
	continue;
      }
      if (!strncmp(buf,".write",6)) {
	unsigned long d;
	d=strtoul(buf+6,NULL,0);
	printf("write(0x%02lx) ack=%d\n", d,i2c_sendbyte(d));	
	usleep(20000UL);
	continue;
      }
    }
    if (!strncmp(buf,"ver",3)) { 
	verbose = (verbose+1)%4;
	printf("verbose=%d %s\n",verbose,verbose>1?"on":"off");
	continue;
    } else if (!strncmp(buf,"del",3)) { 
	delval=strtoul(buf+3,NULL,0);
	printf("delay loop for bits on rx/tx=%d\n",delval);
	continue;
    } else if (!strncmp(buf,"ewrs",4)) { 
	int adr,val=0;
	char *endp;
	adr= (int) strtoul(buf+4,&endp,0);
	if (endp!=NULL)	val= (int) strtoul(endp+1,&endp,0);
	else val=0;
	SET(data,1); SET(clock,0); FLUSH;
	ClockPulses(8,"--");
	SendData(adr,val,28);
	ClockPulses(40,"--"); SET(data,1);	
	fprintf(stdout,"sent 0x%x (%d)\n",adr,val);
	continue;
    } else if (!strncmp(buf,"ewr",3)) { 
	int adr,val,valpr;
	int cnt;
	char *endp;
	adr= (int) strtoul(buf+3,&endp,0);
#if 0
	ThruSendaddr(0xa0, adr);
#else
	SET(data,1); SET(clock,0); FLUSH;
	ClockPulses(8,"--");
	val=0xa0|((adr&0x700)>>7);
	SendData(val,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	cnt=GetAck(0);
	fprintf(stdout,"sent 0x%0x, clock_cnt=%d\n",val,cnt);
	ClockPulses(4,"--");
	SendData(adr&0xff,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	cnt=GetAck(0);
	fprintf(stdout,"sent 0x%xclock_cnt=%d\n",adr&0xff,cnt);
#endif
	ClockPulses(4,"--");
	valpr= (int) strtoul(endp+1,&endp,0);
	while ( *endp != '\0' ) {
	  val= (int) strtoul(endp+1,&endp,0);
	  SendData(valpr, *endp != '\0' ,28);
	  ClockPulses(40,"--"); SET(data,1);
	  cnt=GetAck(0);
	  fprintf(stdout,"set 0x%x clock_cnt=%d\n",valpr,cnt);
	  valpr=val;
	}
	continue;
    }
    if (!strncmp(buf,"erd",3)) { 
	int adr,val;
	int cnt;
	char *endp;
	adr= (int) strtoul(buf+3,&endp,0);
#if 0
	ThruSendaddr(0xa1, adr);
#else
	SET(data,1); SET(clock,0); FLUSH;
	/* send 0xaa and ADR */
	ClockPulses(4,"--");

	/* SendData(0xa1,1,28); */
	val=0xa1|((adr&0x700)>>7);
	SendData(val,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	cnt=GetAck(0);
	fprintf(stdout,"sent 0x%0x, clock_cnt=%d\n",val,cnt);
	ClockPulses(4,"--");
	SendData(adr&0xff,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	cnt=GetAck(0);
	fprintf(stdout,"sent 0x%xclock_cnt=%d\n",adr,cnt);
#endif
	/* read value */
	ClockPulses(96,"--");
	val=RecvData(28);
	ClockPulses(16,"--"); SET(data,1);
	cnt=GetAck(0);
	fprintf(stdout,"read=%d = 0x%x  clock_cnt=%d\n",val,val,cnt);
	gaddr=adr+1;
	continue;
    } else if (!strncmp(buf,"nrd",3)) { 
	int val;
	int cnt;
	/* read value */
	ClockPulses(96,"--");
	val=RecvData(28);
	ClockPulses(16,"--"); SET(data,1);
	cnt=GetAck(0); 
	fprintf(stdout,"read addr=0x%x: %d = 0x%x  clock_cnt=%d\n",gaddr,val,val,cnt);
	gaddr++;
	continue;
    } else if (!strncmp(buf,"cackr",5)) { 
	int dcmp=0,cnt=0;
	if ( 1 != sscanf(buf+4,"%u", &dcmp)) dcmp=0;
	SET(data,1); 
	cnt=GetAck(dcmp);
	fprintf(stdout,"clock_cnt=%d\n",cnt);
	continue; 
    } else if (!strncmp(buf,"cack",4)) { 
	int dcmp=0,cnt=0;
	if ( 1 != sscanf(buf+4,"%u", &dcmp)) dcmp=0;
	SET(data,1); 
	cnt=GetAck(dcmp);
	fprintf(stdout,"clock_cnt=%d\n",cnt);
	continue; 
    } else if (!strncmp(buf,"cp",2)) { 
	int d;
	if ( 1 != sscanf(buf+2,"%u", &d)) d=1;
	ClockPulses(d,"..");
	lpb_refresh(&lpb);
	printf("clock=%d data=%d\n", GET(clock_f), GET(data_f));
	continue;

/*   for MM2 cards, try starting jig, and enter following commands:
        rx 11   => 11 bytes should show 3f 67 2f 00 11 14 00 03 68 90 00
        cp 200 
        tx 0xca 0x20 0x0 0x0 0x1       ( x x page offset length)
	rx 1    => the value "0x20" should be read
        tx 0x5a => write value "0x5a" at eeprom address page<<8+offset
	rx 2    => values 90 & 00 read
 */
    } else if (!strncmp(buf,"rx",2)) { 
	int nb,val;
	int cnt;
	char *endp;
	nb= (int) strtoul(buf+3,&endp,0);
	for (cnt=0; cnt<nb; cnt++) {
	  val=RecvDataMM2(delval);
	  fprintf(stdout,"got 0x%02x\n",val);
	}
	continue;
    } else if (!strncmp(buf,"tx",2)) { 
	int val;
	char *endp;
	val= (int) strtoul(buf+2,&endp,0);
	while ( *endp != '\0' ) {
	  TxDataMM2(val,delval);
	  val= (int) strtoul(endp+1,&endp,0);
	}
	ClockPulses(10,"");
	continue;
    }

    if(*buf == 'p') { doSimple("power", p_power, buf+1); continue; }
    if(*buf == 'm') { doSimple("mclr",  p_mclr,  buf+1); continue; }
    if(*buf == 'c') { doSimple("clock", p_clock, buf+1); continue; }
    if(*buf == 'd') { doSimple("data",  p_data,  buf+1); continue; }
    if(*buf == 'q')  break;
    if(*buf == 'r') {
	lpb_refresh(&lpb);
	printf("clock=%d data=%d\n", GET(clock_f), GET(data_f));
	continue;
    }

    if(sscanf(buf, "%i %d", &bits, &num) != 2) {
	printf("?\n");
	continue;
    }

    if(bits & ~((1<<num)-1)) {
	printf("extraneous bits!\n");
	continue;
    }

    printf("0x%04x (%d bits) => 0x%04x\n", bits, num, pipeBits(bits, num));
  }

}

int main(int argc, char **argv)
{
    verbose = 1;
    set_progpath(argv[0]);
    progSetup();
    jig();
    progShutdown();

#ifdef __MSDOS__
    exit(0);
#endif
    return 0;

}
