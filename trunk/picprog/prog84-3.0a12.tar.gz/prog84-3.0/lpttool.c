/*** (C) 1994-> Wim Lewis
 *** Another debugging tool for checking the parallel port
 ***/

#ifndef __MSDOS_
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include "io_ports.h"
#ifdef linux
#define __KERNEL__
#include <asm/semaphore.h>   /* fix for newer kernels */
#include <linux/wait.h>      /* fix for newer kernels */
#include <linux/lp.h>
#undef __KERNEL__
#endif

#ifdef __FreeBSD__
#define	LP_PERRORP	0x08
#define	LP_PSELECD	0x10
#define	LP_POUTPA	0x20
#define	LP_PACK		0x40
#define	LP_PBUSY 	0x80
#endif

#define IBUFLEN 128
#define LPT1_BASE  (0x378)             /* where LPT1: is on most h/w */

/* These assume that 'base' == LPT1_BASE or equiv. */
#define lp_data   (iot.base)               /* write to this to change D0-D7 */
#define lp_status (iot.base+1)             /* read from this to get status */
#define lp_ctl    (iot.base+2)             /* write to change the ctl lines */

struct lp_io_usage iot = { iot_parallel, LPT1_BASE, 3};



int main(int argc, char *argv[]) {

    char buf[IBUFLEN];
    unsigned char ch;

    if (argc == 2)
	iot.base = atoi(argv[1]);
    if ((argc != 1) || (! iot.base)) {
	fputs("Bad usage! No biscuit!\n", stderr);
	exit(8);
    }

    open_io(&iot);  /* opens /dev/port */

    printf("base = %d (0x%x)\n", iot.base, iot.base);

    while (fgets(buf, IBUFLEN, stdin)) {
	if (buf[0] == '?') {
	    ch = in_byte(lp_data);
	    printf("<-- %d (0x%02x)\n", (int)ch, (int)ch);
	} else if (!buf[0] || buf[0] == '\n') {
	    ch = in_byte(lp_status);
	    printf("<+1 %d (0x%02x):", (int)ch, (int)ch);
	    if (!(ch & LP_PBUSY))
		printf(" BUSY");
	    if (!(ch & LP_PACK))
		printf(" ACK");
	    if (ch & LP_POUTPA)
		printf(" OUT-OF-PAPER");
	    if (ch & LP_PSELECD)
		printf(" ONLINE");
	    if (!(ch & LP_PERRORP))
		printf(" ERROR");
	    printf("\n");
	} else {
	    ch = (unsigned char)atoi(buf);
	    out_byte(lp_data, ch);
	    printf("--> %d (0x%02x)\n", (int)ch, (int)ch);
	}
    }
    close_io();  /* release /dev/port */
    return(0);
}
