/*** (C) 1994-> Wim Lewis and others (Credits file)

   io_ports.h - defs & decls for lower level bit I/O routines

   written and copyright 1994,2000 Wim Lewis
   wiml@{{netcom,omnigroup}.com,hhhh.org}

   distribution & re-use ok as long as you use this power wisely
   and only for good, never for evil
**/

#ifndef IO_PORTS_H
#define IO_PORTS_H

/* Note: Bit masks for using the status (base+1) and ctl (base+2) ports can 
   be found in /usr/include/linux/lp.h under Linux. Be sure to use 
   the LP_Pwhatever constants and *not* the LP_whatever constants 
   (which are for the device driver's status word, not the hardware's). */

/***
 ***  Stuff in lp_io.c
 ***/

#define MAX_PORT_COUNT 7

/* This describes the way the hardware interface is being used */
struct lp_io_usage {
  /* What kind of hardware interface are we using? */
  enum {
    eoftable=0,
    iot_unknown = eoftable,
    iot_parallel,
    iot_serial,
    iot_awusb
  } hw_type;
  /* NOTE if you change the above enum you must change the parseInfo
     table in lp_cfg.c to match! */
  
  int  base;  /* base I/O address */
  int  count; /* number of I/O addresses used */
  
  /* Flags describing each port */
  struct {
    unsigned short readbits, writebits;
  } flags[MAX_PORT_COUNT];
  
  int ports_in_use; /* bit 0 = base +0, bit 1 = base +1,.... */
};

/* This allows simple buffering of the bit changes to a line printer port */
struct lp_io
{
  /* port in/out flags, base address, etc. */
  struct lp_io_usage io_usage;

  int  fd;    /* file descriptor, if any */

  /* Most recently written/read values */
  unsigned last[MAX_PORT_COUNT];

  /* Desired values */
  unsigned wanted[MAX_PORT_COUNT];
};

void lpb_open(struct lp_io *);
void lpb_close(struct lp_io *);

void lpb_flush(struct lp_io *);  	/* write out all buffered changes */
void lpb_refresh(struct lp_io *);	/* read in current values */

/* These two functions use "bit indicators" encoded into an int;
   see the bitmasks below. */
int  lpb_test(struct lp_io *, int);
void lpb_write(struct lp_io *, int, int);

/* Bit indicators are encoded into ints and are passed to the
   set, reset, & test macros. Note that BI_TYPE is the offset from
   the parallel port base I/O address.

   NOTE: the serial port uses three bits (8 registers).
*/

#define BI_OFFSET    000007 /* Bit offset within the word         */
#define BI_DATA      000000 /* Data bit?                          */
#define BI_STAT      000010 /* Status bit?                        */
#define BI_CTL       000020 /* Control bit?                       */
#define BI_TYPE      000070 /* Mask for DATA/CTL/STAT etc.        */
#define BI_TYPE_SHIFT 3
#define BI_INVERSE   000100 /* Negative logic                     */

/* Type codes to go in the lptype field of the name vector. */
enum {
  /* these are in the vector passed in to lp_cfg_read() */
  /* previously defined lpeoftable = 0 */
  lpc_readbit  = 01001,       /* name is for a read bit indicator */
  lpc_writebit = 02001,       /* name is for a write bit indicator */
  lpc_rwbit    = 03001,       /* name is for a bidirectional bit */
  lpc_bit      = 00001,       /* name is for a bit, no direction */
  lpc_number,                 /* name is for an integer */
  lpc_flag,                   /* name is a flag, takes no value */

  /* these should only need to be used internally by lp_cfg.c */
  lpc_portbase,   /* port base address (an integer) */
  lpc_hwtype,     /* name specifies kind of port to use */
  lpc_atype       /* name specifies kind of adapter in use (delete me!) */
};

/* masks for lpc_readbit, etc. */
#define LPC_TYPEMASK 00777
#define LPC_READBIT  01000
#define LPC_WRITEBIT 02000
#define LPC_ALIAS    04000  /* alternate name for another bit */

enum { /* lpc_eof=0, */ /* lpc_number=1, */ /* lpc_bits=2, */ /* lpc_abits=4 , */ 
       lpc_no_power_C4C8=8, lpc_type=0x4000 };
enum { lpc_br870=870, lpc_uni4=4, lpc_br875=875 };

/* Associates a name with a bit indicator or other value. */
struct lp_name { char *name; int lptype; int *value; };

/* read a fileful of name-indicator pairs */
int lpb_cfg_read(const char *, /*struct lp_name *,*/ struct lp_io_usage *);
void lpb_dump_names(/*int , struct lp_name * */ struct lp_io_usage *);
void lpb_set_bit_use(struct lp_io_usage *, int, int, int);
void lpb_set_extra_delay(struct lp_io_usage *);      /* extra read delay */

/***
 *** Low-level I/O routines.
 ***/

void open_io(struct lp_io_usage *iot);          /* open port */
void close_io(void);                            /* close port */

unsigned char in_byte(unsigned int);            /* read one byte */
void out_byte(unsigned int, unsigned char);     /* write one byte */

#ifdef HAVE_USB
void open_usb(struct lp_io_usage *);
void close_usb(struct lp_io_usage *);
#endif

#endif /* IO_PORTS_H */

