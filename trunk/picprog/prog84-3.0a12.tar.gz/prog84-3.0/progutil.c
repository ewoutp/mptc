/*** (C) 1999-> Frank Damgaard and others (Credits file)
 * progutil.c
 *
 * misc. utilities for dump84 and prog84.
 */

#include <stdio.h>
#include "prog84.h"
#include "progutil.h"

int prog_w=0, read_w=0;

/* local */
int verify=0;
int EEWrThru=0;

/* slightly modified version from picasm 1.06 :
 * Write one line of Intel-hex file
 */
void write_hex_record(FILE *fp,
                           int reclen, /* length (in words) */
                           int loc, /* address */
                           pic_instr_t *data, /* pointer to word data */
                           int format) /* IHX8M or IHX16 */
{
  int check = 0;

  if (format==BLANK_CHECK) return;
  switch(format) {
    case IHX8M:
      fprintf(fp, ":%02X%04X00", 2*reclen, 2*loc);
      check += ((2*loc) & 0xff) + (((2*loc) >> 8) & 0xff) + 2*reclen;
      break;

    case IHX16: 
    case IHX8D:
      fprintf(fp, ":%02X%04X00", reclen, loc);
      check += (loc & 0xff) + ((loc >> 8) & 0xff) + reclen;
      break;
  }
  while(reclen--) {
    switch(format) {
    case IHX8M:
      fprintf(fp, "%02X%02X",
	      (int)(*data & 0xff), (int)((*data >> 8) & 0xff));
      break;
    case IHX8D:
      /* only 8 bit data, upper 8 bits zero */
      fprintf(fp, "%02X", (int)(*data & 0xff));
      break;
      
    case IHX16:
      fprintf(fp, "%02X%02X",
	      (int)((*data >> 8) & 0xff), (int)(*data & 0xff));
      break;
    }
    check += (*data & 0xff) + ((*data >> 8) & 0xff);
    data++;
  }

  /* write checksum, assumes 2-complement */
  fprintf(fp, "%02X" HEX_EOL, (-check) & 0xff);
}


void write_ver_errEE(char *s, unsigned char *buf, WORD adr,WORD len) {
  int i;
  fprintf(stderr,"%s %04x",s,adr);
  for (i=0; i<len; i++) fprintf(stderr," %02x",buf[i]);
  fputc('\n',stderr);
}

void ResetEE(WORD val) {
/* if val > 255 write a testpattern - repeated every 16 bytes */
/* The routine could be optimized by only writing blocks that are different,
   this would require first reading the eeprom */

    unsigned char *ibuf, *rbuf;
    unsigned short i,j,siz;

    siz=chip_p->page_size;
    rbuf = malloc(siz);
    ibuf = malloc(siz);

    for (i=0; i<siz; ibuf[i++]= val>255? i : val&0xff  ) ;    
    for (i=0; i<chip_p->eeprom_size; i+=siz) {
	if (val>255) { ibuf[0]=i >> 8; ibuf[1]= i&0xff; }
	i2c_pagewrite(i, ibuf, siz);
	i2c_waitack(10000); /* wait up to 10 ms */
	if (verify) {
	  i2c_seqread(i, rbuf, siz);
	  for (j=0; j<siz; j++) if (rbuf[j]!=ibuf[j]) j=siz+1;
	  if (j >= (siz+1)) {
		write_ver_errEE("     ",ibuf,i,siz);
		write_ver_errEE("ERR: ",rbuf,i,siz);
	  }
	}
    }
    prog_w +=i;
    free(rbuf);
    free(ibuf);
}


void programEE(int addr, int count, unsigned char *ibuf) {
/* The routine could be optimized by only writing blocks that are different,
   this would require first reading the eeprom */

    unsigned char *rbuf;
    unsigned short i,j,cnt,siz;

    siz=chip_p->page_size;
    rbuf = malloc(siz);

    for (i=addr; i<addr+count ; i+=siz) {
	cnt=count+addr-i>siz ? siz: count+addr-i;
	if (i>=chip_p->eeprom_size) continue;
	if (verbose>1) write_ver_errEE("[wr: ",&ibuf[i-addr],i,cnt);
	i2c_pagewrite(i, &ibuf[i-addr], cnt);
	i2c_waitack(10000); /* wait up to 10 ms */
	if (verify) {
	  i2c_seqread(i, rbuf, cnt);
	  for (j=0; j<cnt; j++) if (rbuf[j]!=ibuf[i-addr+j]) j=siz+1;
	  if (j >= (siz+1)) {
		write_ver_errEE("     ",&ibuf[i-addr],i,cnt);
		write_ver_errEE("ERR: ",rbuf,i,siz);
	  } else if (verbose>1) write_ver_errEE("[rd: ",&ibuf[i-addr],i,cnt);

	}
    }
    prog_w +=count;
    free(rbuf);
}


void ClockPulses(int clks, char *s) {
	int d=0;
        if (verbose>2) fprintf(stderr,"%s{",s);
	while (clks-- >=0) {
	  if ((verbose==2) && (clks %10 == 1)) fputc('.',stderr);
	  SET(clock,1); FLUSH; 
	  if (verbose>2) fprintf(stderr,"%d",d);
	  d=GET(data_f); 
	  SET(clock,0); FLUSH; 
	}
        if (verbose>2) fprintf(stderr,"}\n");
}


int GetAck(int dcmp) {
  int d,cnt=0;
  SET(clock,0); FLUSH; 
  if (verbose>2) fprintf(stderr,"(");
  do {
	SET(clock,1); FLUSH; 
	d=GET(data_f); cnt++;
	if (verbose>2) fprintf(stderr,"%d",d);
	SET(clock,0); FLUSH; 
  } while (d != dcmp && cnt<0x7fff) ;
  if (verbose>2) fprintf(stderr,")\n");
 return cnt;
}

void SendData(int val, int contdata, int nclks) {
  int cnt;  /* nclcks = 28 */
  for (cnt=0; cnt<=7; cnt++) {
	  ClockPulses(nclks,"");
	  if (verbose>2) fprintf(stderr,"W%d",val&1);
	  SET(data, val & 1); val >>= 1; FLUSH;
  }
  ClockPulses(nclks-4,"");  /* 24 */
  if (verbose>2) fprintf(stderr,"END=%d", contdata==0);
  SET(data, contdata == 0); FLUSH;

}

int RecvData(int nclks) {
  int d=0,mask=1;
  int cnt;
  for (cnt=0; cnt<=7; cnt++) {
    d |= GET(data_f)>0 ? mask : 0;
    if (verbose>2) fprintf(stderr,"R%d",d&mask ? 1:0);
   /* fprintf(stderr,".%x-%x.",d,mask); */
    mask <<=1;
    ClockPulses(nclks,"");
  }
  return d;
}

void ThruPower() {
	SET(mclr,0); 
	FLUSH; 
	usleep(100000L); /* reset */
	if (p_power != -1)
	  SET(power,1);
	SET(data,1);
	SET(clock,0);
	FLUSH;
}

void ThruSendaddr(int comm, int addr) {
	int ackcnt,j;
	ThruPower();
	ackcnt=GetAck(0);
	if (verbose>1) fprintf(stderr,"wait ACK: clock_cnt=%d\n",ackcnt);
	SET(data,1); 
	ClockPulses(8,"--");
	j=comm|((addr&0x700)>>7);
	SendData(j,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	ackcnt=GetAck(0);
	if (verbose>1) fprintf(stderr,"sent 0x%0x, clock_cnt=%d\n",j,ackcnt);
	ClockPulses(4,"--");
	SendData(addr&0xff,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	ackcnt=GetAck(0);
	if (verbose>1) fprintf(stderr,"sent 0x%02x, clock_cnt=%d\n",addr&0xff,ackcnt);
	else if (verbose==1) {
	  if (addr & 0xf) fprintf(stderr,"Address=0x%04x ",addr);
	}
}

void programEEWrThru(int addr, int count, unsigned char *ibuf) {
/* The routine could be optimized by only writing blocks that are different,
   this would require first reading the eeprom */
/* Timing/delay is currently not a problem, since the PIC usually
   runs at 3-4 MHz, and the clock is far so fast when flipping the
   clock pin to run the code on the 16x84 */

    unsigned short i,j,cnt;
    int addrmax = chip_p->eeprom_size;

    if (EEWrThru) addrmax=2048; /* the 24lc16 programmed from 16x84 */
    for (i=addr; i<addr+count ; i+=16) {
	int ackcnt;

	cnt=count+addr-i>16 ? 16: count+addr-i;
	if (i>=addrmax) continue;
	if (verbose>2) write_ver_errEE("[wr: ",&ibuf[i-addr],i,cnt);

	/* this part only works with the pic16x84 program "thru01.asm"
	   since following code and thru01.asm need to be synchronized
	   with the clock pulses this programs sends */

	ThruSendaddr(0xa0,i);

	ClockPulses(4,"--");
	for (j=0; j<cnt; j++) {
	  int val=ibuf[i-addr+j];
	  SendData(val, j<cnt-1 ,28);
	  ClockPulses(40,"--"); SET(data,1);
	  ackcnt=GetAck(0);
	  if (verbose>1) fprintf(stderr,"sent 0x%x clock_cnt=%d %c\n",
				         val,ackcnt,j<cnt-1? ' ' : ':');
	  else if (verbose==1) {
		fprintf(stderr,"%c", j<cnt-1? '.' : ':');
		fflush(stderr);
	  }
	}
	if (verbose==1) fprintf(stderr,"\n");
    }
    prog_w +=count;
}

void ReadThru(WORD adr, unsigned char *data, int len) {
   int j,ackcnt,val;

	if (adr>2047) len=2047; /* max size of 24lc16 */
	if (len>2048) len=2048; /* max size of 24lc16 */
#if 1
	ThruSendaddr(0xa1,adr);
#else
	SET(mclr,1);
	if (p_power != -1)
	  SET(power,1);
	SET(data,1);
	SET(clock,0);
	FLUSH;

	ackcnt=GetAck(0);
	if (verbose>1) fprintf(stderr,"wait ACK: clock_cnt=%d\n",ackcnt);
	SET(data,1); 
	ClockPulses(4,"--");
	j=0xa1|((adr&0x700)>>7);
	SendData(j,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	ackcnt=GetAck(0);
	if (verbose>1) fprintf(stderr,"sent 0x%0x, clock_cnt=%d\n",j,ackcnt);
	ClockPulses(4,"--");
	SendData(adr&0xff,1,28);
	ClockPulses(40,"--"); SET(data,1);	
	ackcnt=GetAck(0);
	if (verbose>1) fprintf(stderr,"sent 0x%x clock_cnt=%d\n",adr&0xff,ackcnt);
	else if (verbose==1) {
	  if (adr & 0xf) fprintf(stderr,"Address=0x%04x ",adr);
	}
#endif
	for (j=adr; j<adr+len; j++) {
	   /* read value */
	   ClockPulses(95,"--"); /* 990320: was 96 */
	   if (verbose==1 && (j&0xf)==0)
		fprintf(stderr,"\nAddress=0x%04x ",j);
	   data[j-adr]=val=RecvData(28);
	   if (verbose==1) fprintf(stderr," %02x",val);
	   ClockPulses(16,"--"); SET(data,1);
	   ackcnt=GetAck(0); 
	   if (verbose>1)
	     fprintf(stderr,"read[0x%04x]=0x%02x clkcnt=%d\n",
		     j,val,ackcnt);
	}	
        if (verbose==1) fprintf(stderr,"\n");
}

void dumphexEEData(FILE *fout, WORD min_addr, WORD max_addr, int format)
{ /* max_addr is actually min_addr+length */
    int buf_count,beg_addr, rel_addr;
    unsigned char *bbuf;
    pic_instr_t buf[16];
       
#if 1
    /* i2c: faster blockread/sequential read from eeprom */
    /* thru: not so fast */

    /* make sure starting at even address , write_hex() needs this */
    if (min_addr & 1) min_addr&=0xfffe; 
    if (max_addr & 1) max_addr= (max_addr&0xfffe)+2;
    bbuf=calloc(max_addr-min_addr+1, sizeof(unsigned char));
    if (EEWrThru) ReadThru(min_addr, &bbuf[0], max_addr-min_addr);
    else i2c_seqread(min_addr,&bbuf[0],max_addr-min_addr);
    rel_addr=0; beg_addr=min_addr; 
    for (buf_count = 0 ; rel_addr+min_addr < max_addr ; ) {
	buf[buf_count] = bbuf[rel_addr++]&0xff; 
	buf[buf_count++] |= (bbuf[rel_addr++]<<8) & 0xff00;
	if (buf_count >= 8) {
           write_hex_record(fout, buf_count, beg_addr, buf, format);
	   beg_addr +=buf_count;
	   buf_count = 0;
	}
    }
    if (buf_count>0)
           write_hex_record(fout, buf_count, beg_addr, buf, format);
    free(bbuf);
#else
    /* slower read : */
    beg_addr=min_addr;
    for (buf_count = 0 ; min_addr < max_addr ; min_addr++) {
	buf[buf_count] = i2c_read(min_addr++) &0xff; /* data eeprom only 8 bit */
	buf[buf_count++] |= (i2c_read(min_addr)<<8) & 0xff00; /* data eeprom only 8 bit */
	if (buf_count >= 8) {
           write_hex_record(fout, buf_count, beg_addr, buf, format);
	   beg_addr +=buf_count;
	   buf_count = 0;
	}
    }
    if (buf_count)
           write_hex_record(fout, buf_count, beg_addr, buf, format);
#endif
}


void programEEIntel(FILE *fp,int format)
{
    char buf[512];
    unsigned cl, ll, bl, bh, base, len, type;
    unsigned char code_buf[32];
    int i;
    int addrmax = chip_p->eeprom_size;

    if (EEWrThru) addrmax=2048; /* the 24lc16 programmed from 16x84 */
    while (fgets(buf, 512, fp)) {
	if (verbose) {
	  fixbuf_crlf(buf);
	  fprintf(stderr,"--- read <%s>\n",buf);
	}
	if (buf[0]!=':') { /* print bad line */
	    continue;
	}
	sscanf(buf+1,"%02x%02x%02x%02x",&ll,&bh,&bl, &type);
	if (ll == 0) continue; /* avoid processing zero length lines */
	len=  ll;
	base= (bh<<8) + bl;
	if (base < addrmax) {
	    for (i=0; i<len; i++) {
		sscanf(buf+9+i*2,"%02x",&cl);
		code_buf[i]= cl;
	    }
	    /* do not write beyond end of eeprom */
	    if (len+base>addrmax) len=addrmax-base;
	    if (len>0) {
	        if (verbose) 
		  fprintf(stderr,
			  "(ee) Writing %d bytes at addr 0x%04x\n", len, base);
		if (EEWrThru) programEEWrThru(base, len, code_buf);
		else programEE(base, len, code_buf);
	    }
	}
	if (type == 1) break;
    }
}

char *fixbuf_crlf(char *buf) {
  if (buf) {
    char *cpe= buf+strlen(buf)-1;
    if (*cpe=='\n' || *cpe=='\r') {
      *cpe='\0';
      cpe--;
      if (*cpe=='\n' || *cpe=='\r') *cpe='\0';
    }
  }
  return buf;
}
/* old version */
#if 0
void programEEIntelThru(FILE *fp)
{
    int addrmax = chip_p->eeprom_size;

    char buf[512];
    
    unsigned cl, ll, bl, bh, base, len, type;
    unsigned char code_buf[32];
    int i;

    while (fgets(buf, 512, fp)) {
	if (verbose) {
	  fixbuf_crlf(buf);
	  fprintf(stderr,"--- read <%s>\n",buf);
	}
	if (buf[0]!=':') { /* print bad line */
	    continue;
	}
	sscanf(buf+1,"%02x%02x%02x%02x",&ll,&bh,&bl, &type);
	len=  ll;
	base= (bh<<8) + bl;
	if (base < addrmax) {
	    for (i=0; i<len; i++) {
		sscanf(buf+9+i*2,"%02x",&cl);
		code_buf[i]= cl;
	    }
	    if (verbose) fprintf(stderr,"(p) Writing %d words at addr 0x%04x\n",len, base);
	    /* some hex files have adresses at addr==max! */
	    if (len+base>=chip_p->eeprom_size) len=chip_p->eeprom_size-base-1;
	    if (len>0 ) programEE(base, len, code_buf);

	}
	if (type == 1) break;
    }
}

#endif
