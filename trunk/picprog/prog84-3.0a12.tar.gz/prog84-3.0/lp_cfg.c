/*** (C) 1994-> Wim Lewis and others (Credits file)
 *** lpb_cfg_read() and helpers
 ***
 *** NOTE that any entry in the names vector with with the name "base"
 *** is treated specially; it is read as an integer (with C syntax for
 *** octal & hex) instead of being parsed as a bit spec
 ***
 *** Also note that the parseBit() routine is very simple minded right
 *** now and should probably be extended a little bit

   The second part parses a (very simple) configuration file format
   to fill in an array of bit indicators. This is lpb_cfg_read(),
   which takes a filename, a pointer to an array of (struct lp_name)s,
   and the length of the array, and tries to fill in the array from the
   data file. There is a companion function, lpb_dump_names, which
   takes an array or structs and its length, and dumps them to stdout
   for debugging.
 ***/

#include "prog84.h"
#include "io_ports.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h> /* for strtoul() */

/* size of line buffer for reading lp_cfg */
#define MAXLINE 512

#define CFG_NAME_COUNT 3
static struct lp_name cfg_namev[] = {
  { "port",    lpc_hwtype,              NULL },
  { "base",    lpc_portbase,            NULL },
  { "adapter", lpc_atype,               NULL },
  { "",        eoftable,                NULL }
};

static struct lp_name config_names[] = {
/*    { "base",    lpc_number, &lpb.base }, */
    { "loop",    lpc_number, &p_loopcnt},
    { "no_power_C4C8", lpc_flag, &p_no_power_C4C8},
    /* standard names */
    { "power",   lpc_writebit,   &p_power    },
    { "mclr",    lpc_writebit,   &p_mclr     },
    { "clock",   lpc_writebit,   &p_clock    },
    { "data",    lpc_writebit,   &p_data     },
    { "clock_f", lpc_readbit,    &p_clock_f  },
    { "data_f",  lpc_readbit,    &p_data_f   },
    { "vpp2",    lpc_writebit,   &p_vpp2     },
    { "vpp3",    lpc_writebit,   &p_vpp3     },

    /* alternate names */
    { "rb6",    lpc_writebit | LPC_ALIAS,   &p_clock    },
    { "rb7",    lpc_writebit | LPC_ALIAS,   &p_data     },
    { "rb6_f",  lpc_readbit  | LPC_ALIAS,   &p_clock_f  },
    { "rb7_f",  lpc_readbit  | LPC_ALIAS,   &p_data_f   },
    { "scl",    lpc_writebit | LPC_ALIAS,   &p_clock    },
    { "sda",    lpc_writebit | LPC_ALIAS,   &p_data     },
    { "scl_in", lpc_readbit  | LPC_ALIAS,   &p_clock_f  },
    { "sda_in", lpc_readbit  | LPC_ALIAS,   &p_data_f   },
#if 0
/* default settings for some pic-programmers : */
/* !warning! : this now goes in appropriate prog84rc.XXXX file  */
    { "uniprogIV", lpc_type|lpc_uni4, &p_progtype},
    { "br875",   lpc_type|lpc_br875, &p_progtype},
    { "br870",   lpc_type|lpc_uni4, &p_progtype},
    /* david tait's popular replicated design */
    { "tait",         lpc_type|lpc_tait_invert, &p_progtype},
    { "tait_invert",  lpc_type|lpc_tait_invert, &p_progtype},
    { "tait_7405",    lpc_type|lpc_tait_invert, &p_progtype},
    { "tait_direct",  lpc_type|lpc_tait_direct, &p_progtype},
    { "tait_7407",    lpc_type|lpc_tait_direct, &p_progtype},
    /* asamicros.com hk-asaprog */
    { "asaprog",      lpc_type|lpc_tait_invert, &p_progtype},
    /* kitsrus.com kits 96 & 119 */
    { "k96",          lpc_type|lpc_tait_invert, &p_progtype},
    { "k119",         lpc_type|lpc_tait_invert, &p_progtype},
    /* doban bojan p16pro40 */
    { "p16pro40",     lpc_type|lpc_tait_invert, &p_progtype},
    /* dontronics.com dt001 (normally 7407 hex buffer) */
    { "dt001",        lpc_type|lpc_tait_direct, &p_progtype},
#endif
    { "",       eoftable,     NULL }
};

/* symbolic pin name table */
struct sym_bit_def {
  char *name;              /* pin name */
  int nameLen;             /* length of pin name */
  int value;               /* bit spec for this pin */
};

/* numeric pin name table, for names like "foo27" */
struct num_bit_def {
  char *name;              /* alpha portion of pin name */
  int nameLen;             /* length of alpha portion */
  int min, max;            /* valid range of numeric portion */
  int offset;              /* add to numeric portion to get bit spec */
  int value;               /* rest of bit spec */
};

/* information that changes for each kind of i/o hardware */
struct hw_parse_info {
  char *name;
  struct sym_bit_def *symBits;
  struct num_bit_def *numBits;
  int default_base;
  int portcount;
  char *portNames[MAX_PORT_COUNT];
};

#define NUM_HWTYPES 5
static struct lp_name iot_namev[] = {
  { "parallel",  iot_parallel, NULL },
  { "lpt",       iot_parallel, NULL },
  { "serial",    iot_serial,   NULL },
  { "com",       iot_serial,   NULL },
  { "awusb",     iot_awusb,    NULL },
  { "",          eoftable,     NULL}
};

static struct num_bit_def lpNumBits[] = {
  { "d",  1,   0, 7, 0,  BI_DATA },
  { "s",  1,   0, 7, 0,  BI_STAT },
  { "c",  1,   0, 7, 0,  BI_CTL  },
  { NULL, 0,   0, 0, 0,  0       }
};

static struct sym_bit_def lpSymBits[] = {
    { "busy",    4, BI_INVERSE | BI_STAT | 7 },
    { "ack",     3, BI_STAT | 6 },
    { "error",   5, BI_STAT | 3 },
    { "online",  6, BI_STAT | 4 },
    { "nopaper", 7, BI_STAT | 5 },

    { "select",  6, BI_INVERSE | BI_CTL | 3 },
    { "init",    4, BI_CTL | 2 },
    { "autolf",  6, BI_INVERSE | BI_CTL | 1 },
    { "strobe",  6, BI_CTL | 0 },
//#warning Add other symbolic names.

    { NULL,    0, 0 }
};

static struct num_bit_def awusbNumBits[] = {
  { "d",  1,   0,  7,  0,  000 },
  { "d",  1,   8, 15, -8,  010 }, 
  { NULL, 0,   0,  0,  0,  0 }
};

static struct sym_bit_def awusbSymBits[] = {
  { NULL, 0, 0 }
};

static struct sym_bit_def serialSymBits[] = {
    { "TxD", 3, 030 | 6 },    /* base +3, bit 6 --- actually break enable */
    { "RTS", 3, 040 | 1 },    /* base +4, bit 1 */
    { "DTR", 3, 040 | 0 },    /* base +4, bit 0 */
    { "CTS", 3, 060 | 4 },    /* base +6, bit 4 */
    { "DSR", 3, 060 | 5 },    /* base +6, bit 5 */
    { "RI",  2, 060 | 6 },    /* base +6, bit 6 */
    { "CD",  2, 060 | 7 },    /* base +6, bit 7 */
    { NULL,  0, 0       }
};

/* note this must match the enum in io_ports.h */
struct hw_parse_info parseInfo[] = {
  {
    /* iot_unknown */
    "none",
    NULL, NULL, 0, 0, { NULL }
  },
  {
    /* iot_parallel */
    "parallel port",
    lpSymBits, lpNumBits, 
    0x378, 3,
    { "data", "status", "control", NULL }
  },
  {
    /* iot_serial */
    "serial port",
    serialSymBits, NULL,
    0x3f8, 8,
    {  "tx", "ier", "iir/fcr", "lcr", "mcr", "lsr", "msr" }
  },
  {
    /* iot_awusb */
    "AW USB board",
    awusbSymBits,  awusbNumBits,
    0, 2,
    { "data0", "data1", NULL }
  }
};

static int parseBit(char *, struct sym_bit_def *, struct num_bit_def *);
static const struct lp_name *findName(const char *name, int namelen,
				      const struct lp_name *namevec);
				     
static const struct lp_name *parseName(const char *line,
				       const struct lp_name *namevec);

int lpb_cfg_read(const char *filename,
		 /*struct lp_name *namev,*/
	     struct lp_io_usage *iotype)
{
    FILE *fp;
    char buf[MAXLINE];
    char *line, *cp;
    int wordlen;
    int portnr;
    int bitspec;
    struct lp_name *namev=config_names; 
    struct hw_parse_info *parseinfo;
    const struct lp_name *wordptr;

    /* initialize the iotype struct */
    iotype->hw_type = iot_unknown;
    iotype->base = -1;
    iotype->count = 0;
    for(portnr = 0; portnr < MAX_PORT_COUNT; portnr ++) {
      iotype->flags[portnr].readbits = 0;
      iotype->flags[portnr].writebits = 0;
    }

    parseinfo = NULL;

    /* open the configuration file */
    fp = fopen(filename, "r");
    if (!fp) {
	perror(filename);
	return -1;
    }

    while(fgets(buf, MAXLINE, fp)) {
#ifdef LPBDEBUG
	fprintf(stderr,"<%s>\n", buf); 
#endif

	/* Trim leading whitespace. */
	for (cp = buf; *cp && isspace(*cp); cp++)
	    ;
	line = cp;

	/* Remove comments. */
	if ( (cp=strchr(line, '#'))!=0 )
	    *cp = (char)0;

	/* Skip blank lines. */
	if (!*line)
	    continue;

	/* Extract the first word of the line. */
	for (cp = line; *cp; cp++)
	    if(isspace(*cp) || (*cp == '=') || (*cp == ':'))
		break;

	wordlen = cp - line;

#ifdef LPBDEBUG
	fprintf(stderr,"[key <%.*s>]\n", wordlen, line); 
#endif

	/* Skip past the separator, if any */
	while(*cp && isspace(*cp))
	    cp++;
	if ((*cp == '=') || (*cp == ':'))
	    cp++;

	/* Find out what kind of word this is. */

	wordptr = findName(line, wordlen, cfg_namev);
	if (!wordptr)
	  wordptr = findName(line, wordlen, namev);

#ifdef LPBDEBUG
	if (wordptr)
	  fprintf(stderr,"[index %d: name=%s type=0x%x]\n",
		  word, wordptr->name, wordptr->lptype); 
#endif

	if (!wordptr) {
	  fprintf(stderr, "%s: don't know what to do with \"%.*s\"\n",
		  filename, wordlen, line);
	  continue;
	}

	/* First info in the cfg file must be the port type (serial,
	   parallel, or USB) */
	if (!iotype->hw_type && wordptr->lptype != lpc_hwtype) {
	  fprintf(stderr, "%s: must specify port type first\n", filename);
	  return -1;
	}

	/* Parse the word's value. */
	switch (wordptr->lptype & LPC_TYPEMASK) {
	case lpc_bit:
	    bitspec = parseBit(cp, parseinfo->symBits, parseinfo->numBits);
	    if (bitspec < 0) {
	      fprintf(stderr, "%s: can't parse bit spec for signal \"%s\"\n",
		      filename, wordptr->name);
	      break;
	    }
	    *(wordptr->value) = bitspec;
	    lpb_set_bit_use(iotype, bitspec, 
			    ( wordptr->lptype & LPC_READBIT )? 1 : 0,
			    ( wordptr->lptype & LPC_WRITEBIT )? 1 : 0);
	    break;
	case lpc_number:
	    *(wordptr->value) = (int) strtoul(cp, (char **)NULL, 0);
	    break;
	case lpc_portbase:
	    iotype->base = (int) strtoul(cp, (char **)NULL, 0);
	    break;
	case lpc_flag:
	    (*(wordptr->value)) ++;
	    break;
	case lpc_hwtype:
	  /* parse a hardware type decl (serial, parallel, usb) */
	  if (iotype->hw_type) {
	    fprintf(stderr, "%s: multiple hardware type declarations\n",
		    filename);
	    return -1;
	  }
	  wordptr = parseName(cp, iot_namev);
	  if (!wordptr) {
	    fprintf(stderr, "%s: unknown port type\n", filename);
	    continue;
	  }
	  iotype->hw_type = wordptr->lptype;
	  parseinfo = &(parseInfo[iotype->hw_type]);
	  iotype->base = parseinfo->default_base;
	  iotype->count = parseinfo->portcount;
	  if (iotype->hw_type == iot_serial) {
	    /* The code I'm replacing always reads port 1. I don't know why. */
	    iotype->flags[0].readbits |= 0x100;
	  }
	  break;
	}
    }/* end of for-each-line loop */
    fclose(fp);
    return(0);
}

static int parseBit(char *spec,
		    struct sym_bit_def *symBits,
		    struct num_bit_def *numBits)
{
    char *cp = spec;
    int val = 0,
    	valid = 0,
    	i;
    int len, alphaLen;

#ifdef LPBDEBUG
    fprintf(stderr,"[parsing bit <%s>]\n", spec); 
#endif

    if (!*cp)
	return -1;

    do {
#ifdef LPBDEBUG
	fprintf(stderr,"@%s,%d\n", cp, val);  
#endif
	switch(*cp) {
	case ' ': case '\t': case '\n': case '\r':
	    break;     /* ignore whitespace */

	case '!': case '~': case '*':
	    val ^= BI_INVERSE;  /* inversion */
	    break;

	default:
	  
	  for(len = 1; ; len++)
	    if (!cp[len] || !isalnum(cp[len]))
	      break;

	  /* search for this word in the symBits table */
	  for (i = 0; symBits[i].name; i++)
	    if (len == symBits[i].nameLen &&
		!strncmp(cp, symBits[i].name, symBits[i].nameLen)) {
	      cp += symBits[i].nameLen - 1;
	      val &= ~(BI_TYPE | BI_OFFSET);
	      val |= symBits[i].value;
	      valid = 1;
	      break;
	    }
	  if (valid)
	    break;

	  /* if not found in the symBits table, check whether the word
	     ends in digits, and search for it in the numBits table */
	  alphaLen = len;
	  while(alphaLen > 0 && isdigit(cp[alphaLen-1]))
	    alphaLen --;
	  if (alphaLen < len && numBits != NULL) {
	    int symVal = atoi(cp + alphaLen);
	    
	    for (i = 0; numBits[i].name; i++)
	      if (alphaLen == numBits[i].nameLen &&
		  !strncmp(cp, numBits[i].name, numBits[i].nameLen) &&
		  symVal >= numBits[i].min &&
		  symVal <= numBits[i].max) {
		cp += len - 1;
		val =
		  (val & ~(BI_TYPE | BI_OFFSET)) |
		  numBits[i].value |
		  (symVal + numBits[i].offset);
		valid = 1;
		break;
	      }
	    if (valid)
	      break;
	  }
	  
	  fprintf(stderr, "unrecognized pin name: \"%s\"\n", cp);
	  return -1;
	} /* end of switch statement */
    } while(*++cp);
    return (valid ? val : -1);
}

static const struct lp_name *findName(const char *name, int namelen,
				      const struct lp_name *namevec)
{
  while(namevec->lptype!=eoftable) {
    if (namelen == strlen(namevec->name) &&
	!strncmp(name, namevec->name, namelen))
      return namevec;
    namevec ++;
  }
  return NULL;
}

static const struct lp_name *parseName(const char *line,
				       const struct lp_name *namevec)
{
  int wordlen;

  /* skip leading whitespace */
  while (*line && isspace(*line))
    line ++;

  if (!*line)
    return NULL;

  wordlen = 1;
  while (line[wordlen] && !isspace(line[wordlen]))
    wordlen ++;

  return findName(line, wordlen, namevec);
}

void lpb_dump_names(/*int hw_type */ /*, struct lp_name *namev */
	     struct lp_io_usage *iotype)
{
    int v, ttype;
    struct lp_name *namev=config_names;
    int hw_type= iotype->hw_type;

    fprintf(stderr, "hardware type = %s\n", parseInfo[hw_type].name);
    if (hw_type==iot_parallel || hw_type==iot_serial) 
      fprintf(stderr,"base=0x%03x\n",iotype->base);

    for (; namev->lptype!=eoftable ; namev++ ) {
        /* skip aliases */
        if (namev->lptype & LPC_ALIAS)
	  continue;

	fprintf(stderr,"%s = ", namev->name);

	ttype = namev->lptype & LPC_TYPEMASK;
	if (ttype == lpc_number) {	
	    fprintf(stderr,"0x%03x\n", *(namev->value));
	    continue;
	} else if (ttype == lpc_bit) {
	   v = *(namev->value);
	   if (v == -1)
	     fprintf(stderr,"undefined\n");
	   else {
	     int portnum = (v & BI_TYPE) >> BI_TYPE_SHIFT;

	     if (portnum < parseInfo[hw_type].portcount &&
		 parseInfo[hw_type].portNames[portnum] != NULL)
	       fputs(parseInfo[hw_type].portNames[portnum], stderr);
	     else
	       fprintf(stderr, "[base+%d]", portnum);
	     fprintf(stderr," bit %d%s",
		     v & BI_OFFSET,
		     (v & BI_INVERSE) ? " inverted":"");
	     if ( hw_type==iot_serial) {
	       struct sym_bit_def *symBits=parseInfo[hw_type].symBits; 
	       for (; symBits->name; symBits++) 
		 if (v== (symBits->value & (BI_TYPE|BI_OFFSET)))
		   fprintf(stderr," (%s)",symBits->name);
	     }
			  
	     fprintf(stderr,"\n");
	   }
	} else if (ttype == lpc_flag) {
	  fprintf(stderr, "%s (value=%d)\n", 
		    *(namev->value)? "on":"off", *(namev->value));	  
	} else {
	   fprintf(stderr, "(??? value=%d)\n", *(namev->value));
	}
    }
}

void lpb_set_bit_use(struct lp_io_usage *iotype,
		     int bitspec,
		     int readable, int writable)
{
  int ioport, bitmask;

  ioport = (bitspec & BI_TYPE) >> BI_TYPE_SHIFT;
  bitmask = 1 << (bitspec & BI_OFFSET);

  if (ioport >= MAX_PORT_COUNT) {
    /* should never happen */
    fprintf(stderr, "Bit spec is out of range!\n");
    exit(1);
  }

  if (readable)
    iotype->flags[ioport].readbits |= bitmask;
  if (writable)
    iotype->flags[ioport].writebits |= bitmask;
}

