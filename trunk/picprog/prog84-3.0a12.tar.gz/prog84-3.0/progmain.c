/** (C) 1994-> Wim Lewis and others (Credits file)
 *** Source for PIC programmer
 *** originally: prog84
 ***
 *** Added support for serial programmer, lr 02-apr-96
 ***/

#define EXTERN
#include <ctype.h>
#include <string.h>

#include "prog84.h"
#include "progutil.h"
#ifdef __MSDOS__
#include "dosutil.h"
#else
#include <getopt.h>
#endif
       
/*** 26-mar-95   Luigi Rizzo: fixed a missing loadconf in programID()
 *** 01-apr-96   Luigi Rizzo: added clear device (-z)
 *** 01-jan-1999 Frank Damgaard: 
 ***             - improved reading 8bit Intel Hex files
 ***             - added -C, and modified -c and -C to override fuse settings
 ***             - reading of commandline options changed to allow mixing
 ***               options that don't require parameters
 ***             - for Intel Hex files moved fuse and ID programming
 ***               to after program and data are written.
 ***             - fixed a missing loadconf in programFuse()
 *** -> look at the file "Changes"
 ***/
static char *loptarg;	/* local copy of optarg from getopt() */
static char *command;	/* program name */

const char *usagetxt = 
    "Usage: %s [options]\n"
    "Programs a Microchip's PIC MCU or serial EEPROM.\n\n"
    "  -T CHIP, --chip=CHIP        Select CHIP : -1 0 1684 2408 2416 2465 ...\n"
    "  -x FILE, --intel8=FILE      Read hex8 intel file & program.\n"
    "  -y FILE, --intel16=FILE     Read hex16 intel file & program.\n"
    "  -p FILE, --pictools=FILE    Read pictools format file & program.\n"
    "  -P SPEED, --serial=SPEED    Apply power and run serial port at given speed.\n"
    "  -Q, --power-off             Remove power from the device.\n"
    "  -a, --verify                Verify after programming each location.\n"
    "  -F, --write-all             Force program even if value is already correct.\n"
    "  -W, --write-diff            Only write changed values.\n"
    "  -N, --no-write              Do not write to ROM, emulate writing.\n"
    "  -i NN,NN,NN,NN; --id=NN,NN,NN,NN\n"
    "                              Program ID locations (no spaces between numbers)\n"
    "  -O NN, --osc-val=NN         Oscillator calibration value (decimal NNN,\n"
    "                                octal 0NNN, hex 0xNNN). For 12c5xx only.\n"
    "  -c NN, --fuses-val=NN       Program fuses (decimal NNN, octal 0NNN,\n"
    "                                hex 0xNNN).\n"
    "  -C XX, --fuses=XX           Program fuses, XX={CWULXHR}.\n"
    "                                C=CodeProtext on, W=Watchdog on, U=PowerUp on\n"
    "                                OSC: L=LP, X=XT, H=HS, R=RC\n"
    "  -z, --clear                 Fully clear the device (program & config).\n"
    "  -Z NN, --eeprom=NN          EEPROM set to NN, NN must follow 'z' (no spaces)\n"
    "                                only affects 24cXX eeproms, not eeprom on PIC.\n"
    #ifdef __MSDOS__
    "  -l DELAY, --loop-delay1=DELAY\n"
    "                              Delay 1.\n"
    "  -m DELAY, --loop-delay2=DELAY\n"
    "                              Delay 2.\n"
    #endif
    "  -v, --verbose               Be more verbose.\n"
    "  -L, --list-chips            Print a list supported chips & exit.\n"
    "  -V, --version               Print version.\n"
    "  -h, --help                  Print this help message & exit.\n";

void usage(int n, char *s) {
   if (s!=NULL) fprintf(stderr,"%s: %s\n",command, s);
   if (n>0) fprintf(stderr,usagetxt,command);
   exit(n);
}

/* types of verification */
#define FORCE  0x1
#define VERIFY_AFTER   0x2

/* Argument processing functions */
long int shiftNum(char *);
long int shiftFuses(char *);
FILE *shiftFile(char *);

int picPC; /* what we think the PIC's pc is right now */

int	progMode= 0 ;/* default: program */

BOOL progUp=0;     /* has the programmer been initialized? */
extern int verify; /* what kinds of verification we do */
extern int prog_w,
          read_w;  /* total programmed and read words */
int errors = 0;    /* how many programming errors */
BOOL fuses_done=0; /* if commandline fuses, skip from hexfile */

//#undef doProgram
//#define doProgram() {prog_w++;}	// for debugging purposes
static void jumpTo12(unsigned);
static void jumpTo16(unsigned);
static void (*jumpTo)(unsigned) = jumpTo16; /* ptr to the actual jumpTo func */
static unsigned oscval;

/* fuses */
#define WDT_FUSE 0x04  /* watchdog timer */
#define PUT_FUSE 0x08  /* power-up timer */
#define CP_FUSE  0x10  /* code protect */
#define FUSE_MASK 0x1F /* only these bits are implemented */

/* programming routines */
void programID(unsigned int *);
void programPicTools(FILE *);
void programIntel(FILE *, int format);
void programFuse(unsigned int);
void programInit();

int handleSerial(int speed)
{
    static int cycle=0;
    int base, a;
    WORD32 d;
    programInit();
    base=lpb.io_usage.base;
    if (base!=0x3f8 && base!=0x2f8 && base!=0x3e8 && base != 0x2e8) {
	fprintf(stderr,"Sorry, no serial port connected\n");
	return 0;
    }
    d = 115200/ speed ;
    fprintf(stderr,"Serial port at %d baud (0x%04x)\n", speed, d);
    if (d < 1 || d > 0xffff) {
	fprintf(stderr,"sorry, unsupported speed\n");
	return 0;
    }
    out_byte(base+4, 1 ); /* MCR: only set DTR */
    a= 3 ; /* 8 data, 1 stop, no par, ... */
    out_byte(base+3, a | 0x80);
    out_byte(base, d & 0xff);
    out_byte(base+1, (d>>8) & 0xff);
    out_byte(base+3, a);
    for ( ;; ) {
	int c;
	char d[2];
	d[1]='\0';
	d[0]='\0';
	if (!(in_byte(base+5) & 0x1) ) {
	    continue;
	}
	c=in_byte(base);
	if ( (c>=' ' && c<= 0x7f) || c==13 ||c==10 || c==8 || c==9) d[0]=c;
	cycle++;
	if (verbose) fprintf(stderr,"rx [%6d] [0x%02x] 0x%02x %s\n", cycle,
		in_byte(base+5), c, d );
	else fprintf(stderr,d);
	fflush(stderr);
    }
}

void programInit()
{
    if (!progUp) {
	progSetup();
	progUp = 1;
    }
    power_and_reset();
    picPC = chip_p->extraflags & FL_PIC12SERIES ? 0xfff : 0;
    jumpTo = chip_p->extraflags & FL_PIC12SERIES ? jumpTo12 : jumpTo16;
    progMode=0;
}

/***
 *** jumps to a given address, possibly resetting the programmer.
 *** PIC12 version
 ***/
static void
jumpTo12(unsigned addr)
{
    if (    !progUp ||	/*** was not active ***/
	    addr == 0xfff ||	/*** fuse address ***/
	    addr < picPC ) {	/*** must go backwards ***/
	programInit();
	if (addr == 0xfff) return;	/* fuses */
	incAddr();
	picPC=0;
    }
    for ( ; picPC < addr; picPC++) incAddr();
}

/***
 *** jumps to a given address, possibly resetting the programmer.
 *** PIC16 version
 ***/
static void
jumpTo16(unsigned addr)
{

    /***
     *** requests < 0x2100 = data_addr mean working on program
     *** > 2100 work on data. Data can only be done if were in data
     *** or previously were reset.
     ***/
    if (    !progUp ||	/*** was not active ***/
	    addr < picPC ||	/*** must go backwards ***/
	    (addr >= data_addr  && (picPC !=0 && picPC < data_addr) ) )
	programInit();
    /***
     *** at this point, picPC is certainly <= addr
     ***/
    
    if (addr >= data_addr && picPC==0)
      picPC= data_addr;	/*** doing data ***/
    else if (picPC < picid_addr && addr >= picid_addr) {
      loadConfiguration(0x3FFF);
      picPC = picid_addr;
    }
    
    for ( ; picPC < addr; picPC++)
      incAddr();
}

/***
 *** command "z" : clear Pic
 ***/
void ResetPic() {
    if (chip_p->extraflags & FL_NO_ERASABLE) {
       fprintf(stderr,"Error: this device isn't electronically erasable.\n");
       return;
    }
    jumpTo(0x2007);
    pipeBits(SC_CMD1,6);
    pipeBits(SC_CMD7,6);
    doProgram();   /* calls usleep(10000), and gives the required
		     minimum delay of minimum 10 msec */
    pipeBits(SC_CMD1,6);
    pipeBits(SC_CMD7,6);
}

#ifdef __MSDOS__
extern int loopd1,loopd2;
#endif

static
struct option longopts[] =
{
#ifdef __MSDOS__
  { "loop-delay1", 1, 0, 'l' },
  { "loop-delay2", 1, 0, 'm' },
#endif
  { "serial",      1, 0, 'P' },
  { "power-off",   0, 0, 'Q' },
  { "verbose",     0, 0, 'v' },
  { "version",     0, 0, 'V' },
  { "chip",        1, 0, 'T' },
  { "verify",      1, 0, 'a' },
  { "help",        0, 0, 'h' },
  { "id",          0, 0, 'i' },
  { "osc-val",     1, 0, 'O' },
  { "fuses-val",   1, 0, 'c' },
  { "fuses",       1, 0, 'C' },
  { "intel16",     1, 0, 'y' },
  { "intel8",      1, 0, 'x' },
  { "clear",       0, 0, 'z' },
  { "eeprom",      1, 0, 'Z' },
  { "pictools",    1, 0, 'p' },
  { "write-all",   0, 0, 'F' },
  { "write-diff",  0, 0, 'W' },
  { "no-write",    0, 0, 'N' },
  { "list-chips",  0, 0, 'L' },
  { 0, 0, 0, 0 }
};

int main(int largc, char *largv[])
{
    int i,opt,format;
    WORD zval=0;
    unsigned int id[4];
    unsigned int f;
    FILE *fp;

    verbose = 0;
    emulate_write=0;
    command=largv[0];
    set_progpath(largv[0]);
    opterr=0; /* disable error messages in getopt() */
    read_w=0;
    prog_w=0; 

    while ( (opt=getopt_long(largc, largv, "l:m:P:QvVT:ahi:O:c:C:y:x:zZ:p:FWLN", longopts, 0)) != -1  ) {
	 if (  (!progUp) && (strchr("icCzxyp",opt)!=NULL)) {
		/*** was not active ***/
		programInit();
	 }	
	 loptarg=optarg;
	 /* fprintf(stderr,"option=%c (%d/%c)  [%s]\n",opt,opt,optopt,loptarg); */
	 switch(opt) {
	 case 'P':
	    progSetup();
	    handleSerial(shiftNum("serial port rate (bps)"));
	    break;
	 case 'Q':
	    programInit();
	    progShutdown();
	    exit(0);
	 case 'V':
	    printf("%s: Version %s\n",command,PROGVERS);
	    break;
	 case 'v':
	    verbose ++;
	    if(verbose > 1) { p84_verbose ++; i2c_debug++; } 
	    break;
	 case 'i':
	    if (chip_p->type==PIC) {
		for(i=0; i<4; i++) id[i] =  shiftNum("id number");
		/* fprintf(stderr,"%d %d %d %d\n",id[0],id[1],id[2],id[3]);
		   exit(0); return 0; */
		programID(id);
	    } else usage(1,"No program id in eeprom");
	    break;
	 case 'O':
	    if (chip_p->type==PIC && chip_p->extraflags & FL_PIC12SERIES) {
		oscval = 0xc00|(0xff&shiftNum("oscillator calibration value"));
	    } else usage(1,"Oscillator calibration only for PIC12C5xx");
	    break;
	 case 'c':
	    if (chip_p->type==PIC) {
		f = shiftNum("configuration word / fuses");
		programFuse(f);
		fuses_done=1;
	    } else usage(1,"No fuses in eeprom");
	    break;
	 case 'C':
	    if (chip_p->type==PIC) {
		f = shiftFuses("configuration word / fuses");
		/* fprintf(stderr, "main.cp=%s 0x%04x\n", cp,f); */
		programFuse(f);
		fuses_done=1;
	    } else  usage(1,"No fuses in eeprom");
	    break;
#ifdef __MSDOS__
	 case 'l': loopd1=shiftNum("loop delay 1");
	    break;
	 case 'm': loopd2=shiftNum("loop delay 2");
	    break;
#endif
	 case 'Z':
	      zval=shiftNum("eeprom reset value");
	 case 'z':
	      if (opt == 'z') zval=0;
	      if (chip_p->type==PIC) ResetPic();
	      else ResetEE(zval);
	    break;
         case 'y':
	 case 'x':
            format= opt=='x' ? IHX8M : IHX16;
	    fp = shiftFile("hex intel format file");
	    if (chip_p->type==PIC) {
		programIntel(fp,format);
	    } else {
		if (format==IHX8M) programEEIntel(fp,format); 
		else usage(1,"No intel hex-16 format for eeprom :(, only Intel hex8 :)");
	    }
	    fclose(fp);
	    break;
	 case 'p':
            format=PICTOOL;
	    if (chip_p->type==PIC) {
		fp = shiftFile("pictools format file");
		programPicTools(fp);
		fclose(fp);
	    } else usage(1,"No pictools format for eeprom :(, only Intel hex :)");
	    break;
	 case 'h': usage(1,NULL);
	    break;
	 case 'T':{
		   int c = -1;
		   int ctp = -1;
		   if (tolower( *loptarg )== 'h') c= -1;
		   else if (tolower( *loptarg )== 'a') c= 0;
		   else c = shiftNum("chip type");
		   ctp = set_chiptype(c);
		   if (ctp<0) usage(0,"no chiptype requested ");
		   programInit();
	         }
		break;
	 case 'a':
	    verify |= VERIFY_AFTER;
	    break;
	 case 'N':
	    emulate_write=1;
	    break;
	 case 'F':
	    verify |= FORCE;
	    break;
	 case 'W': 
	    /* default is only program if newbyte != oldbyte */
	    verify &= ~FORCE;
	    break; 
	 case 'L':
	    printListSupported();
	    return 0;
	 case '?':
	 default: {
		    char txt[64+strlen(largv[optind-1])];
		    sprintf(txt,"unknown option \"%s\"\n", largv[optind-1]);
	            usage(1, txt);
	          }
	 }
   }

    if (largc < 2) usage(1,"");

    if(progUp) progShutdown();

    if (progUp) fprintf(stderr,"Read %d cells, programmed %d\n", read_w, prog_w);

#ifdef __MSDOS__
    exit(0);
#endif
    return 0;

}

/* Programming utilities */

void programID(unsigned int *id)
{
    int i;

    jumpTo(chip_p->extraflags&FL_PIC12SERIES ? chip_p->prog_size : 0x2000);

    if (verbose) {
	fprintf(stderr,"writing config [");
	fflush(stderr);
    }
    if (!(chip_p->extraflags&FL_PIC12SERIES)) loadConfiguration(id[0]);
    for (i = 0; i < 4; i++) {
	char *s=" ";	/* default message */
	unsigned int w=readProg();
	read_w++;
	fprintf(stderr,"ID %d : have 0x%04x, want 0x%04x\n", i, w, id[i]); 
	if (w == id[i] && ! (verify & FORCE) ) {
	} else {
	    loadProg(id[i]); /* needed! XXX */
	    doProgram();    /* includes 10 ms delay */
	    if (chip_p->extraflags & FL_ENDPROGRAM) endProgram(); 
	    if ((verify & VERIFY_AFTER) && (readProg() != id[i])) {
		s="X";
		errors ++;
	    } else {
		s=".";
	    }
	}
	if (verbose) fprintf(stderr,s);
	if (i < 3) {
	    if (verbose) fflush(stderr);
	    incAddr();
	}
    }
    if (verbose) fprintf(stderr,"]\n");
    picPC = chip_p->extraflags&FL_PIC12SERIES ? chip_p->prog_size+3 : 0x2003;
}


void programFuse(unsigned int f)
{
    unsigned int w;

   /* 19990101 FD: dummy jumpTo(0x2000) seems to solve problem with missing
       initialization when only programming fuses */
    jumpTo(0x2000);  /* XXX added FD => initiates a loadconfig */
    w=readProg();    /* 19990101 FD: moved readProg() to after init. */
    jumpTo(0x2007);

    if (verbose) fprintf(stderr,"writing fuses 0x%04x\n",f);

    if ((w & FUSE_MASK) == (f & FUSE_MASK)) {
	if (verbose) fprintf(stderr,"fuses not changed; not re-programmed\n");
	return;
    }

    if (verbose) fprintf(stderr,"writing fuses 0x%04x\n",f);

    loadProg(f);
    doProgram();  /* inlcudes 10 ms delay */

    if (verify & VERIFY_AFTER) {
	int ver = readProg();
	if ((ver & FUSE_MASK) != (f & FUSE_MASK)) {
	    fprintf(stderr, "writing fuses: wrote %04x, verified as %04x\n",
		f, ver);
	    errors ++;
	}
    }
}

void programData(unsigned int addr, int count, unsigned int *buf)
{
    unsigned int w;
    unsigned int *ptr;

again:
    ptr = buf;
    jumpTo(addr);

    if (verbose) {
	fprintf(stderr,"%d words at data offset 0x%04x [", count, addr);
	fflush(stderr);
    }
    while (count) {
	char *s=" ";
	w=readData() & 0xff;
	read_w++;
	if ( w == *ptr && ! (verify & FORCE) ) {
	} else {
	    if (verbose) fprintf(stderr,"0x%04x: want 0x%02x have 0x%02x\n",
			picPC, *ptr, w);
	    loadData(*ptr);
	    doProgram();  /* includes 10 ms delay */
	    s=".";
	}
	if (verbose) {
	    fprintf(stderr,s);
	    fflush(stderr);
	}
	if ((readData() & 0xff)  != *ptr) {
	    fprintf(stderr,"\bX");
	    fflush(stderr);
	    errors ++;
	    programInit();
	    goto again;
	}
	incAddr();
	picPC ++;
	count --;
	ptr ++;
    }

    if (verbose) { 
	fprintf(stderr,"]\n");
    }
}

int programProg(unsigned int addr, int count, unsigned int *buf)
{
    unsigned int w;
    unsigned int *ptr;
    int retries=0;

again:
    ptr = buf;
    jumpTo(addr);

    if (verbose) {
	fprintf(stderr,"%2d words at offset %04x [", count, addr);
	fflush(stderr);
    }
    while (count) {
	char *s=" ";
	w=readProg();
	read_w++;
	if (chip_p->extraflags&FL_PIC12SERIES && picPC==chip_p->prog_size-1) {
	    if ((w&0xf00)!=0xf00 && (w&0xf00)!=0xc00) {
		fprintf(stderr,"\nIncorrect oscillator calibration value "
				"(0x%.3x). Left unchanged.\n", w);
		*ptr = w;
	    } else {
		if (!oscval && (*ptr&0xff)!=0xff) oscval = *ptr;
		if (oscval) {
		    if ((w&0xff)!=0xff) {
		        fprintf(stderr,"\nOscillator calibration value is not "
			    "blank (0x%.3x). Left unchanged.\n", w);
		        *ptr = w;
	} else {
		        *ptr = oscval;
		    }
		}
	    }
	}
	if ( w != *ptr || (verify & FORCE) ) {
	    loadProg(*ptr);
	    doProgram();  /* incl. 10 ms delay */
	    if (chip_p->extraflags & FL_ENDPROGRAM) { 
		endProgram();  /* extra command required for 16c6x/7x/9xx */
	    }
	    s=".";
	}
	if (verbose) {
	    fprintf(stderr,s);
	    fflush(stderr);
	}
	if (readProg() != *ptr) {
	    fprintf(stderr,"\bX");
	    fflush(stderr);
	    if ((chip_p->extraflags & FL_NO_ERASABLE) || (++retries>5)) {
		fprintf(stderr,"\nWrite error at 0x%04X\n",picPC);
		return 1;
	    }
	    errors ++;
	    programInit();
	    goto again;
	}
	retries=0;
	incAddr();
	picPC ++;
	count --;
	ptr ++;
    }

    if (verbose) { 
	fprintf(stderr,"]\n");
    }
    return 0;
}


void programIntel(FILE *fp, int format)
{
    /* For future improvements of prog84, the following adresses could 
       be read from a PIC database */
    int picprogmax = chip_p->extraflags & FL_PIC12SERIES ?
	0x1000 : chip_p->prog_size;

    BOOL have_fuses=0, have_id=0;
    unsigned id[4];
    unsigned fuses=0x3FFF;

    char buf[512];
    unsigned ch, cl, ll, bl, bh, base, len, type;
    unsigned code_buf[32];
    int i;

    while (fgets(buf, 512, fp)) {
	if (verbose)  fprintf(stderr,"--- read <%s>\n",fixbuf_crlf(buf));
	if (buf[0]!=':') { /* print bad line */
	    continue;
	}
	sscanf(buf+1,"%02x%02x%02x%02x",&ll,&bh,&bl, &type);
        if (format==IHX16) {
	  len = ll; base = (bh<<8) + bl;
	} else { /* IHX8M */
	  len=  (ll) /2; base= ((bh<<8) + bl) /2;
	}
	if (base < picprogmax) {
	    /*** normal code ***/
	    for (i=0; i<len; i++) {
		sscanf(buf+9+i*4,"%02x%02x",&cl, &ch);
		code_buf[i]= format==IHX16 ? (cl<<8)+ch: (ch<<8)+cl;
	    }
	    if (len && verbose) fprintf(stderr,"(p) Writing %d words at addr 0x%04x\n",len, base);
	    /* some hex files have adresses at addr==max! */
	    if (len+base>picprogmax) len=picprogmax-base-1;
	    if (len>0 && programProg(base, len, code_buf)) return;
	} else if (base == picid_addr ) {
	    /*** picid ***/
	    for (i=0; i<len; i++) {
		sscanf(buf+9+i*4,"%02x%02x",&cl, &ch);
		if (i<4) id[i]= format==IHX16 ? (cl<<8)+ch: (ch<<8)+cl;
	    }
	    if (verbose) fprintf(stderr,"(id) 0x%02x 0x%02x 0x%02x 0x%02x\n",id[0],id[1],id[2],id[3]);
	    have_id= len>0;
	} else if (base == fuse_addr) {
	  if (len>0) {
	    /*** fuse ***/
	    sscanf(buf+9,"%02x%02x",&cl, &ch);
	    fuses= format==IHX16 ? (cl<<8)+ch: (ch<<8)+cl;
	    if (verbose) fprintf(stderr,"(fuses) 0x%04x\n",fuses);
	    have_fuses=1;
	  }
	} else if (base >= data_addr) {
	    for (i=0; i<len; i++) {
		sscanf(buf+9+i*4,"%02x%02x",&cl, &ch);
		code_buf[i]= format==IHX16 ? ch : cl;
	    }
	    if (verbose) fprintf(stderr,"(d) Writing %d words at addr 0x%04x\n",len, base);
	    if (len>0 ) programData(base, len, code_buf);
	}
	if (type == 1) break;
    }

    if (oscval) programProg(chip_p->prog_size-1, 1, &oscval);

    if (have_id)
	programID(id);

    if (have_fuses && ! fuses_done)
	programFuse(fuses);
}

void programPicTools(FILE *fp)
{
    BOOL have_fuses=0, have_id=0;
    unsigned id[4];
    unsigned fuses;

    char buf[512];
    unsigned code_addr = 0;
    int i;

    fuses = 0xFFF;

    while (fgets(buf, 512, fp)) {
	switch(*buf) {
	case 0:
	case '\n':
	case '\r':
	case '#':
	    break;
	case 'I':
	    if (sscanf(buf+1, "%i %i %i %i",
		    &id[0], &id[1], &id[2], &id[3]) != 4) {
		fprintf(stderr,"error reading ID numbers\n");
		exit(2);
	    }
	    have_id = 1;
	case 'A':
	    sscanf(buf+1, "%x", &code_addr);
	    break;
	case 'D':
	    {
	    unsigned code_buf[32];
	    int code_count;
	    char *cp;

	    code_count = strtol(buf+1, &cp, 10);
	    if (cp == buf+1) {
		 fprintf(stderr,"error reading data byte count\n");
		 exit(2);
	    }
	    for (i=0; i<code_count; i++)
	        code_buf[i] = strtol(cp, &cp, 16);
	
	    if (programProg(code_addr, code_count, code_buf)) return;
	    code_addr += code_count;
	    break;
	    }
	case 'T':
	    if (atoi(buf+1) != 84) {
		fprintf(stderr, "I'm a 16C84 programmer, but this file as %s",
		    buf);
		exit(2);
	    }
	    break;
	case 'W':
	    have_fuses = 1;
	    fuses &= ~ WDT_FUSE;
	    if (atoi(buf+1)) fuses |= WDT_FUSE;
	    break;
	case 'U':
	    have_fuses = 1;
	    fuses &= ~ PUT_FUSE;
	    if (atoi(buf+1)) fuses |= PUT_FUSE;
	    break;
	case 'P':
	    have_fuses = 1;
	    fuses &= ~ CP_FUSE;
	    if(atoi(buf+1)) fuses |= CP_FUSE;
	    break;
	case 'C':
	    i = atoi(buf+1);
	    have_fuses = 1;
	    fuses = ( fuses & ~3 ) | ( atoi(buf+1) & 3 );
	    break;
	case 'S':
	    fprintf(stderr,"[ignoring pictools file checksum]");
	    break;
	default:
	    fprintf(stderr,"warning: unrecognized line: %s", buf);
	    break;
	}
    }

    if (have_id)
	programID(id);

    if (have_fuses  && ! fuses_done )
	programFuse(fuses);
}


/* Arg parsing functions */


long int shiftNum(char *what)
{   char *end;
    long int val;

    if (loptarg !=NULL) {
	while ( *loptarg==' ')  loptarg++;
	if (*loptarg==',') loptarg++;
    }
    if ((loptarg==NULL) ||  !*loptarg) {
	usage(1,"arglist ends abruptly\n");
    }

    val = strtol(loptarg, &end, 0);
    if (loptarg == end) {
	char txt[128];
	sprintf(txt, "expecting %s, got \"%s\"", what, loptarg);
	usage(1,txt);
    }
    loptarg=end;
    return val;
}

long int shiftFuses(char *what)
{
    long int f;
    if ((loptarg==NULL) || (*loptarg == '\0')) {
	usage(1, "arglist ends abruptly");
    }
    if (chip_p->chiptype!=1684) {
	fprintf(stderr, "Error: symbolic fuses only supported for 16x84 devices\n");
	exit(3);
    }
	f=0x3fe0|CP_FUSE|1;
	while (*loptarg != 0) {
		switch (tolower(*loptarg)) {
		 case 'f': /* dummy */ ; break;
		 case 'u': f |= PUT_FUSE; break;
		 case 'w': f |= WDT_FUSE; break;
		 case 'c': f &= ~CP_FUSE; break;
		 case 'l': f = f&0xfffc;  break;
		 case 'x': f = (f&0xfffc)|1;  break;
		 case 'h': f = (f&0xfffc)|2;  break;
		 case 'r': f = (f&0xfffc)|3;  break;
		 case ',': 
		 case ' ': break; /* skip */
		 default: /* skip / continue */
		   break;
		}
		loptarg++;
	}
    if (*loptarg != '\0') {
	char txt[128];
	sprintf(txt, "expecting %s, got \"%s\"",  what, loptarg);
	usage(1,txt);
    }
    return f;
}

FILE *shiftFile(char *what)
{
    FILE *fp;
    extern char *strerror();

    if ((loptarg==NULL) ||  !*loptarg) {
	usage(1,"arglist ends abruptly");
    }

    fp = fopen(optarg, "r");
    if (!fp) {
	char txt[128];
	sprintf(txt, "can't open %s %s: %s",
		what, optarg, strerror(errno));
	usage(2,txt);
    }
    return fp;
}

