/*** (c) 19990113 Frank Damgaard / GNU Copyleft
 ***
 *** File: thru84.c
 ***
 *** write 24c16 eeprom with "thru02b.asm" program on 16c84/16f84
 ***/

#ifndef __MSDOS__
#include <unistd.h>
#else
#include "dosutil.h"
#endif
#include <stdio.h>
#include <string.h>
#define EXTERN 
#include "prog84.h"
#include "progutil.h"


void start_cfg()
{
    /* clear power, if it still on from previos call */
    SET(mclr, 0);
    if (p_vpp2!=-1) SET(vpp2,0);
    if (p_vpp3!=-1) SET(vpp3,0);
    SET(power, 0);
    SET(clock, 1);
    SET(data, 0);
    FLUSH;
    usleep(200000UL); /* 0,2 s is hopefully enough to reset programmer */

    SET(mclr, 0);
    SET(power, 1);
    SET(clock, 0);
    SET(data, 0);
    FLUSH;
    sleep(2);	/* for the serial prog. charge the capacitor */
    SET(mclr, 0); /* also does a reset */
    FLUSH;
    usleep(50000UL);/* for the serial prog. charge the capacitor */
    SET(mclr, 1);
    FLUSH;
    usleep(50000UL);
}

char *command;
int  startsetup=0;

void usage(char *txt)
{
   if (strlen(txt)>0) fprintf(stderr,"%s: %s\n",command,txt);
   fprintf(stderr, "usage: %s [options]\n"
			" -x filename  write to 24c16 - intel hex8 format\n"
			" -d           dump intel hex8 format\n"
			" -y           dump intel hex16 format\n"
			" -b N         start at address N (dump only)\n"
			" -e N         last address N (dump only)\n"
			" -h           this text\n"
			" -v           more verbose\n"
			" -V           print version\n",
                        command);
   
   if (startsetup) progShutdown();
   exit(1);
}


int main(int argc, char **argv)
{
    int opt,format=IHX8M;
    unsigned beg=0,end=2047;

    set_progpath(argv[0]);

    if ( p_no_power_C4C8 > 0 ) {
      // BR875 has some timing/signal level problems
      // adding the number of ports to read increases delay
      // seems to work
      //lpb.ports_in_use |= 0x3f;
      lpb_set_extra_delay(&(lpb.io_usage));
    }

    command = argv[0];
    opterr=0;
    while((opt=getopt(argc, argv, "hdvyVx:b:e:")) != -1) {
      switch(opt) {
	case 'b': beg= (unsigned) strtoul(optarg, NULL,0); 
		  if (beg>2047) usage("begin address must be < 2048");
		  break;
	case 'e': end= (unsigned) strtoul(optarg, NULL,0); 
		  if (end>2047) usage("end address must be < 2048");
		  break;
	case 'y':
	case 'd': format= opt=='d' ? IHX8M : IHX16;
		    if (!startsetup) {
			usleep(1000L); /* dummy initialize dosutil.c */
			progSetup(); startsetup=1;
			/*fprintf(stderr,"chiptype=%d\n",chip_p->chiptype); */
			if (chip_p->chiptype != 1684) usage("only works with 16x84");
		    }
		  EEWrThru=1;
		  dumphexEEData(stdout,beg,end+1, format);
		  fprintf(stdout,":00000001FF" HEX_EOL); /* end record */
		break;
	case 'x': if (optarg!=NULL) {
		    FILE *fhexin;
		    if (!startsetup) {
			usleep(1000L); /* dummy initialize dosutil.c */
			progSetup(); startsetup=1;
			if (chip_p->chiptype!=1684) usage("only works with 16x84");
		    }
		    fhexin=fopen(optarg, "r");
		    if (fhexin==NULL) {
			char *txt=malloc(60+strlen(optarg));
			if (txt!=NULL)
			  sprintf(txt,"can't open %s: %s\n",
				optarg, strerror(errno));
			else txt="can't open intel hex file";
			usage(txt);
		    }
		    start_cfg();
		    EEWrThru=1;
		    programEEIntel(fhexin,format);
	        }
		break;
	case 'V':
	    printf("%s: Version %s\n",command,PROGVERS);
	    break;
	case 'v': 
		verbose ++;
		if(verbose > 1) { p84_verbose ++; i2c_debug++; } 
		break;
	default: {
                    char txt[128];
                    sprintf(txt,"unknown option \"%c\"\n", optopt);
                    usage(txt);
		}
      }
    }

    if (startsetup) progShutdown();
#ifdef __MSDOS__
    exit(0);
#endif
    return 0;

}


