/*** (C) 1994-> Wim Lewis and others (Credits file)
 *** prog84.c
 ***
 *** these routines use the parallel or serial port
 *** to program a PIC 16C84 in serial mode
 ***/

#include <string.h>
#include <stdlib.h>
#include "io_ports.h"
#include "prog84.h"

int
    p_power   = -1,  /*  Vpp and/or Vdd power (12-14V / 5V) */
    p_mclr    = -1,  /*  mclr on PIC, 0=reset (0V), often == p_power) */
    p_clock   = -1,
    p_data    = -1,
    p_clock_f = -1,
    p_data_f  = -1,
    p_vpp2    = -1,
    p_vpp3    = -1;
int
    /* p_power=0 for cards with C4/C8 connected to 24c16, used by BR875 */
    p_no_power_C4C8 = 0; 
int
    p_loopcnt = -1,
    p_progtype= -1;


struct lp_io lpb;

char *cfg_file = "prog84rc";
char *progpath="" ;

/* If the chips[] array is changed, make sure to change
   the chipstypes in prog84.h : enum {... 
*/

int chiptype = noPICtype;

chip_info chips[]= 
/* name, chiptype, type, prog_size, eeprom_size,
   device_id, id_mask, extraflags */
{
 {"NONE ",noPICtype,PIC,0,    0, 0x000,0x000, 0},
 {"12c5x8",12508, PIC, 0x200, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_PIC12SERIES},
 {"12c5x9",12509, PIC, 0x400, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_PIC12SERIES},
 {"16x84",  1684, PIC, 0x400,64, 0x000,0x0000, 0},
 {"16f84a", 1684, PIC, 0x400,64, 0x540,0x3fe0, 0},
 {"16x61",  1661, PIC, 0x400, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x620",16620, PIC, 0x200, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x621",16621, PIC, 0x400, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x622",16622, PIC, 0x800, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x62",  1662, PIC, 0x800, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x63",  1663, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x64",  1664, PIC, 0x800, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x65",  1665, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x71",  1671, PIC, 0x400, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x710",16710, PIC, 0x200, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x711",16711, PIC, 0x400, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x712",16711, PIC, 0x400, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x716",16716, PIC, 0x800, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x72",  1672, PIC, 0x800, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x73",  1673, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x74",  1674, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x66",  1666, PIC,0x2000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x67",  1667, PIC,0x2000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x76",  1676, PIC,0x2000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x77",  1677, PIC,0x2000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x773",16773, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x774",16774, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x873",16873, PIC,0x1000,128,0x860,0x3fe0, 0},
 {"16x874",16874, PIC,0x1000,128,0x820,0x3fe0, 0},
 {"16x876",16876, PIC,0x2000,256,0x8e0,0x3fe0, 0},
 {"16x877",16877, PIC,0x2000,256,0x9a0,0x3fe0, 0},
 {"16x923",16923, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},
 {"16x924",16924, PIC,0x1000, 0, 0x000,0x0000, FL_ENDPROGRAM|FL_NO_ERASABLE},

 {"24c01",  2401, EEPROM,0, 128, 0,0,0, 8}, /* tested by quozl */
 {"24c08",  2408, EEPROM,0, 1024,0,0,FL_CTRLADDR, 8},
 {"24c16",  2416, EEPROM,0, 2048,0,0,FL_CTRLADDR, 16}, 
 {"24c32",  2432, EEPROM,0, 4096,0,0,FL_2ADDR, 16}, /* not tested */
 {"24c65",  2465, EEPROM,0, 8192,0,0,FL_2ADDR, 32}, /* tested by quozl */
 {"NONE ",noPICtype,PIC,0,0,0,0,0} }; /* <-- used as EOT */

chip_info *chip_p=chips;

int p84_verbose = 0;
int i2c_debug=0;
unsigned i2cdelay=0;   /* if CPU's get to fast in the future for the 24c16 */

chip_info * get_chip_p(int chtype) {
  chip_info *chp= chips;
  ++chp; 
  while ( chp->chiptype!=noPICtype && chp->chiptype != chtype ) {
	++chp; 
  }
  return chp;
}

int set_chiptype(int c) {
/*   set type of chip to "c" ( == chips[].chiptype )
     returns :
        chiptype == c   found
        0 == noPICtype  if not found
        -1              listet available chips
*/
   chip_info *ci = chips;
   chip_p= &chips[0]; chiptype=noPICtype;
   if (c>0) {
	ci = get_chip_p(c);
   } else if (c<0) {
        /* "-T-1" : print list of chips available */
	int cnt=0;
	++ci;
	fprintf(stderr," chips:");
	while (ci->chiptype != noPICtype) {
	  fprintf(stderr," %d",ci->chiptype); 
	  if ( ++cnt % 10 == 0) fprintf(stderr,"\n");
	  ++ci;
	}
	fprintf(stderr,"\n");
	return -1;
   }
   if ( ci->chiptype == noPICtype || c==0) {
      /* with eeprom (2416), test_chip() will try do autodetect*/
      ci= get_chip_p(2416);
   }
   chip_p= ci;
   chiptype= ci->chiptype;
   //fprintf(stderr," %d %s \n",chip_p->chiptype, chip_p->name);
   return ci->chiptype;
}

void printListSupported() {
  int i=1;
  
  fprintf(stderr,"List of supported devices:\n\n"
                 "Chip            Type    Program     Data\n"
                 "----------------------------------------\n");
  while (chips[i].chiptype!=noPICtype) {
      fprintf(stderr,"%-15s %-6s   %6d   %6d\n",chips[i].name,
        chips[i].type==PIC ? "PIC" : "EEPROM",chips[i].prog_size,
        chips[i].eeprom_size);
      i++;
  }
}

static int file_exist(char *s) {
  FILE *f;
  if (s==NULL) return 0;
  if ( (f=fopen(s,"r"))==NULL) return 0;
  fclose(f);
  return 1;
}

/* set program path from argv */
void set_progpath(char *p) {
  char *pr;
  pr=strrchr(p,'/');
  if (pr!=NULL) {  
	int  l;
	l=strlen(p)-strlen(pr);
	progpath=calloc(l+2,sizeof(char));
	strncpy(progpath,p,l+1);
	pr=calloc(l+2+strlen(cfg_file),sizeof(char));
	strcpy(pr,progpath);
	strcat(pr,cfg_file);
  } else pr="";
 /* find lp_cfg:  
    1st.: currentdir; 2nd.: $HOME/.prog84rc; 3rd.:"progpath"/prog84rc */
  if (verbose > 1) fprintf(stderr,"cfg file, try : %s\n",cfg_file);
  if ( ! file_exist(cfg_file) ) {
#ifdef __MSDOS__
    if ( (strlen(pr)>0) && file_exist(pr)) cfg_file=pr;
#else
    char *home;
    char *cf;
    home = getenv("HOME");
    if (home != NULL) {
	cf=calloc(strlen(cfg_file)+strlen(home)+3,sizeof(char));
	strcpy(cf,home); strcat(cf,"/.");
	strcat(cf,cfg_file);
    } else cf=pr;
    if (file_exist(cf)) cfg_file=cf;
    else {
      if (file_exist(pr)) cfg_file=pr;
    }
#endif
  }

  /* read the configuration file */
  if (lpb_cfg_read(cfg_file /*, config_names*/, &(lpb.io_usage))) {
	fprintf(stderr, "error reading cfg file %s\n", cfg_file);
	exit(1);
  }

  /* BR875 hack from Frank Damgaard */
  if ( p_no_power_C4C8 > 0 ) {
	// BR875 has some timing/signal level problems
	// adding the number of ports to read increases delay
	// seems to work
        lpb_set_extra_delay(&(lpb.io_usage));
  }
}

/***
 *** poweron the pic and enter programming mode
 ***/
void power_and_reset()
{
  int cap_charge=1;

  /* clear power, if it still on from previos call */
  SET(mclr, 0);
  if (p_power!= -1)  SET(power, 0);
  SET(clock, 1);
  SET(data, 0);
  if (p_vpp2!=-1) SET(vpp2,0);
  if (p_vpp3!=-1) SET(vpp3,0);
  FLUSH;
  usleep(200000UL); /* 0,2 s is hopefully enough to reset programmer */
  
  /* set power to pic-programmer */
  SET(mclr, 0);
  if (chip_p->type==EEPROM && p_no_power_C4C8>0 && p_power != -1) {
    // eeprom wanted  :
    SET(power,0);   /* BR875 needs Vpp=0 for eeprom. */
    if (p84_verbose) fprintf(stderr,"BR875: Vpp=0\n");
  } else {
    if (p_power!= -1)
      SET(power, 1);	/* the ludpipo serial programmer needs this... */
    if (p_vpp2!= -1) SET(vpp2, 1);
    if (p_vpp3!= -1) SET(vpp3, 1);
  }
  SET(clock, 0);
  SET(data, 0);
  FLUSH;
  if (p84_verbose) fprintf(stderr,"Charging capacitor (%d sec.)...\n",cap_charge);
  sleep(cap_charge); /* wait quite a bit to charge capacitor */
  SET(mclr, 0);
  FLUSH;
  
  usleep(50000UL);
  if (! (chip_p->type==EEPROM && p_no_power_C4C8>0)) {
    // eeprom wanted  :
    SET(mclr, 1);
    FLUSH;
  }
}

int get_pictype() {
  /* Read device ID */
  return 0;
}

void test_chip(int chtp) {
    chip_info *ch_p= get_chip_p(chtp);

#if EEPROM_AUTODETECT
    /* move to ProgSetup() ?*/
    if (ch_p->type==EEPROM && p_no_power_C4C8>0 && p_power != -1) {
	// eeprom wanted on BR875, so turn on eeprom logic:
	SET(power,0); FLUSH ;
    }
#endif

    if (ch_p->chiptype==noPICtype || ch_p->type == EEPROM) {
      /* try to autodetect EEPROM */
#ifdef EEPROM_AUTODETECT
      i2c_start();
      if (i2c_sendbyte((unsigned char) 0xa0)) {
	ch_p = get_chip_p(2465);
	i2c_start();
	if (i2c_sendbyte((unsigned char) 0xae)) ch_p= get_chip_p(2416);
	else if (i2c_sendbyte((unsigned char) 0xa6)) ch_p= get_chip_p(2408);
        fprintf(stderr,"\ndetected eeprom %s ",ch_p->name);
      } else { 
	ch_p= get_chip_p(chtp);
	fprintf(stderr,"\nno eeprom detected ");
      } 
#endif
    }

    fprintf(stderr,"\n%s", ch_p->chiptype != noPICtype ? "using" : "asuming");
    if (ch_p->chiptype==noPICtype) ch_p= get_chip_p(1684);

    fprintf(stderr," %s (%u) chip, capacity %d data, %d code\n",
	    ch_p->name, ch_p->chiptype, ch_p->eeprom_size, ch_p->prog_size);

    chip_p = ch_p;
    chiptype = ch_p->chiptype;
}

int testHW()
{
    int i,j;     /* utility variables */
    int ret[4];  /* array of test results */
    int m;       /* merged test results */

    power_and_reset();

    if (p_mclr == -1 || p_clock == -1 || p_data == -1 || p_data_f == -1) {
	fprintf(stderr, 
	    "Error: I need control over MCLR, clock, and data,\n"
	    "       and I need to be able to read data back.\n");
	return 1;
    }


    if (p84_verbose) {
	fprintf(stderr,"[testing loopback   ");
	fflush(stderr);
    }

    for (i=0; i<4; i++) {
	SET(clock, i&1);
	SET(data, i&2);
	FLUSH;
	usleep(100UL); /* here I can be slow, no problem */
	/* 2001-01-09 UPS:  added REFRESH input , 
	   since FLUSH reads data to soon, and GET only reads buffer */
	REFRESH;
	j = GET(data_f) ? 2 : 0;
	if (p_clock_f != -1)
	    j |= GET(clock_f)? 1 : 0;
	else
	    j |= i & 1;  /* fake it if we don't have it */
	ret[i] = j;
    }

    SET(clock, 0);
    SET(data, 0);
    FLUSH;

    if (p84_verbose)
	fprintf(stderr,"  ]\n");

    /***
     *** analyze the test results. We put our four 2-bit responses
     *** into an int, one per nybble so we can use handy hex notation.
     ***/

    m = (((((ret[3] << 4) | ret[2]) << 4) | ret[1]) << 4) | ret[0];

    if(m == 0x3210)	/*** this is what we expect ***/
	return 0;

    fprintf(stderr, "Bad test results!\n  [data, clock]->[data_f, clock_f]:");
    for(i = 0; i < 4; i ++)
	fprintf(stderr, " %d%d->%d%d", (i>>1)&1, i&1,
		(ret[i]>>1)&1, (ret[i])&1);
    fprintf(stderr,"\n");

    if (p_clock_f == -1)
	fprintf(stderr, "(clock_f simulated since I don't actually have it)\n");

    if (m == 0x3120)
	fprintf(stderr, "clock and data reversed?\n"
	    " (could be either the clock & data lines, or the sense lines)\n"
	);

    switch(m & 0x1111) {
    case 0x0000:
	fprintf(stderr, "clock_f stuck low?\n");
	break;
    case 0x0101:
	fprintf(stderr, "clock_f inverted?\n");
	break;
    case 0x1111:
	fprintf(stderr, "clock_f stuck high?\n");
	break;
    }

    switch(m & 0x2222) {
    case 0x0000:
	fprintf(stderr,"data_f stuck low?\n");
	break;
    case 0x0022:
	fprintf(stderr,"data_f inverted?\n");
	break;
    case 0x2222:
	fprintf(stderr,"data_f stuck high?\n");
	break;
    }

    /***
     *** here I evidently have a failure, and should return 1. However,
     *** I keep on trying in the hope it is a temporary thing.
     ***/

    
    return 0;
}


/*** 
 *** Pipe some bits through the 16C84. Returns the values read from
 *** the data pin at the appropriate point in the cycle for reading
 *** data mem.  In a write, will return 'bits'.  (Unless, of course,
 *** something's wrong.)
 *** When reading set bits=0x7ffe
 ***/

#ifdef __MSDOS__
int loopd1=2,loopd2=200;
#endif

unsigned int pipeBits(unsigned int bits, int count)
{
    unsigned int ret = 0;
    int bit;

    for (bit=0; bit<count; bit++) {
	SET(clock, 1);
	SET(data, bits&1);
	FLUSH;
	/* Minumum 100 ns. delay is needed when programming PIC's
	   specifications require min. 100ns clock low and 100ns clock low.
	   Data must be valid > 80ns before clock transition 1->0
	   FLUSH ( lpb_flush() , lp_refresh() ) usually
	   gives adequate delay on linux/frebsd systems */
	SLEEP100ns(loopd1); /* 0.2 us */

	SET(clock, 0);
	FLUSH;   /* <- loads data in PIC , & reads input */
	ret |= (GET(data_f)? 1 : 0 ) << bit;
	if (p84_verbose > 1)
	    fprintf(stderr,". bit %2d: send %d get %d\n",
		bit, bits&1, GET(data_f)?1:0);

	/* minimum 100ns delay needed : */
	SLEEP100ns(loopd1); /* 0.2us */
	bits >>= 1;
    }
    SET(data, 1); /* the HI-Z state */
    FLUSH;
    /* required guard time of at least 1 usec.
       seems for fast cpu + dos/win at least 1ms is needed !? 
       .... faulty sleep/delay algorithms in DOS */
    SLEEP100ns(loopd2); /* 2.0 us */
    return ret;
}

void xPipeBits(unsigned int bits, int count)
{
    unsigned int ret;

    ret = pipeBits(bits, count);
    if (ret != bits) {
      fprintf(stderr,
	      "ERROR: sent %d bits: %d (0%o), got %d (0%o)\n"
	      "Resetting & powering down.\n",
	      count, bits, bits, ret, ret);
      progShutdown();
      exit(2);
    }
}

/* A generic command-plus-14-bits-to-write call */
void genericWrite(int cmd, unsigned int data)
     /* 6 bits of command, 14 bits of data */
{
    xPipeBits(cmd, 6);		  	/* Send the command */
    xPipeBits((data << 1) & 0x7FFE, 16);	/* send the data */
}

/* A generic command-plus-14-bits-to-read call */
unsigned int genericRead(int cmd)
{
    unsigned int ret;

    xPipeBits(cmd, 6);			/* send the command */
    ret = pipeBits(0x7FFE, 16);		/* read the result */
    return((ret & 0x7FFE) >> 1);	/* remove guard bits */
}


void progSetup()
{
    /* read the configuration file : moved to set_prog_path() */
    /* but print debug info if verbose : */
    if (p84_verbose)
      lpb_dump_names( &lpb.io_usage /*.hw_type*/ /*, config_names*/);

    /* open /dev/port */
    lpb_open(&lpb);

    /* check that the programmer's not totally dead */
    if (testHW()) {
	fprintf(stderr,"\nProgrammer is not responding, aborting.\n");
	exit(1);
    }
    test_chip(chiptype);
    i2cdelay=0;
}

void progShutdown()
{
    if (verbose) fprintf(stderr,"...closing\n");
    SET(mclr, 0);
    FLUSH;
    usleep(10000UL);	/* shutdown... */
    if (p_vpp3!=1) SET(vpp3, 0);
    if (p_vpp2!=1) SET(vpp2, 0);
    if (p_power!=1) SET(power, 0);
    SET(clock, 0);
    SET(data, 0);
    FLUSH;
    lpb_close(&lpb);
}

/* 990103 Frank Damgaard , for eeprom :
   Partially borrowed from i2c driver in "bttv" package,
   and ideas from serp-0.5.tgz
   Datasheet for 24c16 from www.microchip.com was a good help too :)
*/

void i2c_out(WORD c, WORD d) {
  SET(clock,c); SET(data,d); FLUSH;
  /* I2C_DEBUG(fprintf(stderr,"%c",d?'1':'0')); */
  if (i2cdelay) usleep((unsigned long) i2cdelay);  
}

void i2c_start()
{ /* the 1->0 transition while clock=1 => start */
        I2C_SET(0,1);
        I2C_SET(1,1);
        I2C_SET(1,0);
        I2C_SET(0,0);
        I2C_DEBUG(fprintf(stderr,"i2c_start()\n")) ;
}

void i2c_stop()
{ /* the 0->1 transition while clock=1 => stop */
        I2C_SET(0,0);
        I2C_SET(1,0);
        I2C_SET(1,1);
        I2C_DEBUG(fprintf(stderr,"i2c_stop()\n"));
}

void i2c_data(WORD dat){ 
  /* data is clocked during clock=1 */
        I2C_SET(0,dat);
        I2C_SET(1,dat);
        I2C_SET(0,dat);
}


int i2c_ack(int ack)
{ /* 
  ack=1 if acknowledge is wanted
  return:  0  if no acknowledge
           1  if acknowledge 
*/
     int rack;
      /* if data=ack=1 is sent after command, 
         an 0 is received if ok */
	I2C_SET(0,ack);
	I2C_SET(1,ack);
	REFRESH;
        rack = ! I2C_GET();
        I2C_SET(0,ack);
        return rack; 
}

int i2c_sendbyte(unsigned char dat) {
        int i, ack;
    
        I2C_SET(0,0);
        for (i=7; i>=0; i--) i2c_data(dat&(1<<i));
        ack=i2c_ack(I2C_ACK);
        I2C_DEBUG(fprintf(stderr," %02x%c ",(int)dat,ack?'+':'-'));
        return ack;
}

void i2c_sendctrl(unsigned char com, WORD adr) {
  unsigned char ctrl=0;
  /* 2408/2416 uses 2-3 bit of control word for A10-A9-A8 (FL_CTRLADDR) */
  if (chip_p->extraflags & FL_CTRLADDR) ctrl|=adr>>7 ;
  ctrl&=0x0e;
  ctrl|=com;
  i2c_sendbyte(ctrl);
}

int i2c_waitack(unsigned int t) {
/* block write and byte write need up to 10 milleseconds wait time. */
/* t in microseconds */
  int i,ack;
  
  if (t==0) t=1000; else t=t/1000;
  for (i=0; i<t; i++) {
	usleep(10UL);
	i2c_start();
	ack=i2c_sendbyte(EE_CTRL_RD);
	if (!ack) return 0;
  }
  return 1;
}

unsigned char i2c_readbyte(int ack) {
        int i;
        unsigned char dat=0;
    
        I2C_SET(0,1);
        for (i=7; i>=0; i--) {
                I2C_SET(1,1); REFRESH; 
                if (I2C_GET())
                        dat |= (1<<i);
                I2C_SET(0,1);
	}
	i=i2c_ack(ack); 
        I2C_DEBUG(fprintf(stderr,"=%02x%c%c ",(int)dat,ack?'+':'-',i?'+':'-'));
        return dat;
}

void i2c_sendaddr(WORD adr) {
  i2c_sendctrl(EE_CTRL_WR,adr);
  /* 2432/2465 uses an extra address word  (FL_2ADDR) */
  if (chip_p->extraflags&FL_2ADDR ) i2c_sendbyte((adr>>8)&0x1f);
  /* if (chip_p->chiptype==2432 || chip_p->chiptype==2465) 
     i2c_sendbyte(((adr & (chip_p->eeprom_size-1)) >>8));*/
  i2c_sendbyte(adr&0xff);
  I2C_DEBUG(fprintf(stderr," sendaddr=%04x ",(int)adr));
}

void i2c_seqread(WORD adr, unsigned char *data, int len) {
  int i;
  i2c_start();
  i2c_sendaddr(adr);
  i2c_start();
  i2c_sendctrl(EE_CTRL_RD, adr);
  for (i=0; i<len-1; i++) {
	data[i]=i2c_readbyte(I2C_NOACK);
  }
  data[len-1]=i2c_readbyte(I2C_ACK);
  i2c_stop();
}

unsigned char i2c_read(WORD adr) {
  unsigned char data;
  i2c_start();
  i2c_sendaddr(adr);
  i2c_start();
  i2c_sendctrl(EE_CTRL_RD, adr);
  data=i2c_readbyte(I2C_ACK);
  I2C_DEBUG(fprintf(stderr," data=%02x ",(int)data));
  i2c_stop();
  return data;
}


void i2c_pagewrite(WORD adr, unsigned char *dat, WORD PageSize) {
/* Must do an i2c_waitack() after i2c_pagewrite()! */
/* *dat must hold not more than 16 words (unsigned char) !! */
/* 24c16/c08 only has 16 byte storage so pagewrite() only writes 16 bytes*/

  int i;
  i2c_start();
  i2c_sendaddr(adr);
  for (i=0; i<PageSize; i++) i2c_sendbyte(dat[i]);
  i2c_stop();
}

void i2c_write(WORD adr, WORD data) {
/* Must do an i2c_waitack() after i2c_write()! */
  i2c_start();
  i2c_sendaddr(adr);
  i2c_sendbyte(data);
  i2c_stop();
}










