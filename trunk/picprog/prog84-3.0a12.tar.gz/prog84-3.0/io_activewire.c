/*** (C) 2000-> Wim Lewis (Credits file)

  I/O primitives for the ActiveWire USB board on a Linux system.
  
  Linux USB support is still in a state of flux, so this will probably
  break every few kernel revisions. It works with kernel version
  2.2.15pre14 with the USB backport from 2.3.xxx.  Note that
  /usr/src/linux/drivers/usb must have the current USB
  implementation's header files for this to work.

  This code won't download the AN21x1 firmware; you must do that before
  running prog84.
*/

#include "io_ports.h"
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

#include "/usr/src/linux/drivers/usb/usb.h"

/*  #define VERBOSE_IO */
/*  #define VERBOSE_USB */



/* Device descriptor structure (determined by the USB protocol).
   This is in usb.h, but it's inside an ifdef __KERNEL__ ... */
struct usb_device_descriptor {
	unsigned char  bLength;
	unsigned char  bDescriptorType;
	unsigned short bcdUSB;
	unsigned char  bDeviceClass;
	unsigned char  bDeviceSubClass;
	unsigned char  bDeviceProtocol;
	unsigned char  bMaxPacketSize0;
	unsigned short idVendor;
	unsigned short idProduct;
	unsigned short bcdDevice;
	unsigned char  iManufacturer;
	unsigned char  iProduct;
	unsigned char  iSerialNumber;
	unsigned char  bNumConfigurations;
} __attribute__ ((packed));

/* usb ioctl have broken return value, they pretend to be write() */
#define FIX_IOCTL(x)  do { if ((x) > 0) (x) = 0; } while(0);

#define USBROOT "/proc/bus/usb"

#define AW_VENDOR_ID 0x0854
#define AW_PRODUCT_ID 0x0101
#define AW_IO_BYTES 2 /* The board provides 16 bits of I/O */
#define AW_EP_IO 1   /* Endpoint 1 reads/writes the data pins */
#define AW_EP_DDR 2  /* Endpoint 2 is the AW USB board's direction register */

int usb_dev_fd = -1;
int usb_timeout = 100; /* operation timeout value in ms. */

static int find_usb_dev(unsigned int vendor, unsigned int product);

static void usb_bulkwrite(int ep, char *buf, int len)
{
  struct usb_proc_bulktransfer bxfer;
  int ok;

  bxfer.ep = ep;
  bxfer.data = buf;
  bxfer.len = len;
  bxfer.timeout = usb_timeout;

  ok = ioctl(usb_dev_fd, USB_PROC_BULK, &bxfer);
#ifdef VERBOSE_IO
  printf("usb: ep%d %d[%02x %02x] ioctl=%d outlen=%d\n",
	 ep, len, buf[0], buf[1], ok, bxfer.len);
#endif
  FIX_IOCTL(ok);
  if (ok) {
    fprintf(stderr, "usb write failed (%d): ", ok);
    perror("ioctl");
    exit(1);
  }

}

static void usb_bulkread(int ep, char *buf, int len)
{
  struct usb_proc_bulktransfer bxfer;
  int ok;

  bxfer.ep = ep | 0x80;
  bxfer.data = buf;
  bxfer.len = len;
  bxfer.timeout = usb_timeout;

  ok = ioctl(usb_dev_fd, USB_PROC_BULK, &bxfer);
#ifdef VERBOSE_IO
  printf("usb: ep%d inlen=%d ioctl=%d --> %d[%02x %02x]\n",
	 ep, len, ok, bxfer.len, buf[0], buf[1]);
#endif
  FIX_IOCTL(ok);
  if (ok) {
    fprintf(stderr, "usb read failed: ");
    perror("ioctl");
    exit(1);
  }
}

void open_usb(struct lp_io_usage *iot)
{
  unsigned char buf[AW_IO_BYTES];
  int busnr = 1;
  int devnr;
  int portnr;
  char pathbuf[256];
  struct usb_device_descriptor dev_info;

  devnr = find_usb_dev(AW_VENDOR_ID, AW_PRODUCT_ID);
  if (devnr < 0) {
    fprintf(stderr, "Can't find ActiveWire board (vendor=%04x product=%04x)\n",
	    AW_VENDOR_ID, AW_PRODUCT_ID);
    exit(1);
  }
  
  snprintf(pathbuf, 256, "%s/%3.3d/%3.3d", USBROOT, busnr, devnr);
  usb_dev_fd = open(pathbuf, O_RDONLY, 0);
  if (usb_dev_fd == -1) {
    fprintf(stderr, "Can't open USB endpoint \"%s\": %s\n",
	    pathbuf, strerror(errno));
    exit(errno);
  }

  /* Get device info; verify that we have the right board. */
  if (read(usb_dev_fd, &dev_info, sizeof(dev_info)) != sizeof(dev_info)) {
    fprintf(stderr, "Can't read USB device descriptor: %s\n",
	    strerror(errno));
    exit(errno);
  }
  if (dev_info.idVendor != AW_VENDOR_ID ||
      dev_info.idProduct != AW_PRODUCT_ID) {
    fprintf(stderr, "Unexpected vendor=%04x product=%04x: hot swapped?\n",
	    dev_info.idVendor, dev_info.idProduct);
    exit(1);
  }
  if (dev_info.iProduct == 0) {
    /* TODO: Automatically load firmware if necessary? */
    fprintf(stderr, "Found ActiveWrire board but product number is zero.\n"
	    "Has the firmware been loaded?\n");
    exit(1);
  }
  
  /* Configure data direction according to the lp_cfg declarations */
  if (iot->count > AW_IO_BYTES) {
    fprintf(stderr, "open_usb(): io port count exceeds hw capability\n");
    iot->count = AW_IO_BYTES;
  }
  
  /* Set all pins to 0, i.e. inputs */
  memset(buf, 0, AW_IO_BYTES);

  /* Set any pins used for writing to be outputs */
  for(portnr = 0; portnr < iot->count; portnr ++)
    buf[portnr] |= iot->flags[portnr].writebits;

  usb_bulkwrite(AW_EP_DDR, buf, AW_IO_BYTES);
#ifdef VERBOSE_USB
  fprintf(stderr, "ActiveWire USB board initialized.\n");
#endif
}

void close_usb(struct lp_io_usage *iot)
{
  unsigned char buf[AW_IO_BYTES];

  /* Set all pins to 0, i.e. inputs */
  memset(buf, 0, AW_IO_BYTES);
  usb_bulkwrite(AW_EP_DDR, buf, AW_IO_BYTES);

  close(usb_dev_fd);
  usb_dev_fd = -1;
}

unsigned char in_byte(unsigned int offset)
{
  unsigned char buf[AW_IO_BYTES];

  if (offset >= AW_IO_BYTES) {
    fprintf(stderr, "usb ick: there is no byte %d!\n", offset);
    exit(1);
  }

  usb_bulkread(AW_EP_IO, buf, AW_IO_BYTES);
  return buf[offset];
}

void out_byte(unsigned int offset, unsigned char data)
{
  unsigned char buf[AW_IO_BYTES];

  if (offset >= AW_IO_BYTES) {
    fprintf(stderr, "usb ick: there is no byte %d!\n", offset);
    exit(1);
  }

  buf[offset] = data;
  usb_bulkwrite(AW_EP_IO, buf, AW_IO_BYTES);
}

static const char *scan_hex_after_token(const char *buf,
					const char *token,
					unsigned int *out)
{
  const char *cp;
  unsigned long value;

  cp = strstr(buf, token);
  if (!cp)
    return NULL;

  errno = 0;
  value = strtoul(cp + strlen(token), &cp, 16);
  if (errno) 
    return NULL;

  if (value > INT_MAX)
    return NULL;

  *out = value;

  return cp;
}

#define MAXLEN 512
static int find_usb_dev(unsigned int vendor, unsigned int product)
{
  FILE *fp = fopen(USBROOT "/devices", "r");
  char line[MAXLEN];
  int consume;
  int lastdev = -1;
  unsigned int this_vendor, this_product;

  while(1) {
    if(fgets(line, MAXLEN, fp) == NULL)
      break;

    if (line[strlen(line)-1] == '\n')
      consume = 0;
    else
      consume = 1;

#ifdef VERBOSE_USB
    printf("%s%s", line, consume?"\n":"");
#endif
    
    switch(line[0]) {
      case 'T':
	lastdev = -1; /* if we can't parse this, don't re-use the last one */
	/* Bus topology line. Indicates how to find the device named later. */
	/* We want to find the bus number and the device number. */
	/* XXX: There doesn't seem to be a way to extract the bus number!
	   Most systems only have one bus though. */
	
	if (!scan_hex_after_token(line, " Dev#=", &lastdev)) {
	  fprintf(stderr, "unparsable topology line!\n");
	  break;
	}
#ifdef VERBOSE_USB
        printf("  --> lastdev=%04x\n", lastdev);
#endif
	break;
      case 'P':
	/* Device info line 2. If this matches the vendor/product we're
	   looking for, we want to return the info from the previous
	   topology line. */
	if (!scan_hex_after_token(line, " Vendor=", &this_vendor)) {
	  fprintf(stderr, "unparsable device/product line: no Vendor\n");
	  break;
	}
	if (!scan_hex_after_token(line, " ProdID=", &this_product)) {
	  fprintf(stderr, "unparsable device/product line: no ProdID\n");
	  break;
	}
#ifdef VERBOSE_USB
	printf("  --> vendor=%04x product=%04x\n", 
	       this_vendor, this_product);
#endif

	if (this_vendor == vendor && this_product == product) {
	  /* right vendor and product --- return the device number gleaned
	     from the last topology line */
	  return lastdev; /* TODO: also return the bus # */
	}
	break;
      default:
	/* we don't care about the other lines */
	break;
    }

    while(consume) {
      fprintf(stderr, "[... consuming overlong USB description line ...]\n");
      if (fgets(line, MAXLEN, fp) == NULL)
	consume = 0;
      else if(line[strlen(line)-1] == '\n')
	consume = 0;
    }
  }

  /* didn't find what we're looking for. */
  return -1;
}

