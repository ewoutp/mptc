/*** (C) 2001-2002 Frank Damgaard + others
 *** *** hex files convert binary/intel hex file
 ***/

#define EXTERN
#include <ctype.h>
#include <string.h>

#include "prog84.h"
#include "progutil.h"
#ifdef __MSDOS__
#include "dosutil.h"
#else
#include <getopt.h>
#endif

static char *loptarg;   /* local copy of optarg */       
static char *command;	/* program name */

const char *usagetxt = 
    "Usage: %s [options]\n"
    "Hex convert, update an existing hex\n\n"
    "  -T CHIP, --chip=CHIP        Select CHIP : -1 0 1684 2408 2416 2465 ...\n"
    "  -x FILE, --intel8=FILE      Read hex8 intel file & program.\n"
    "  -y FILE, --intel16=FILE     Read hex16 intel file & program.\n"
    "  -p FILE, --pictools=FILE    Read pictools format file & program.\n"
    "  -b FILE, --binary=FILE      Read binary file.\n"
    "  -i NN,NN,NN,NN; --id=NN,NN,NN,NN\n"
    "                              Program ID locations (no spaces between numbers)\n"
    "  -c NN, --fuses-val=NN       Program fuses (decimal NNN, octal 0NNN,\n"
    "                                hex 0xNNN).\n"
    "  -C XX, --fuses=XX           Program fuses, XX={CWULXHR}.\n"
    "                                C=CodeProtext on, W=Watchdog on, U=PowerUp on\n"
    "                                OSC: L=LP, X=XT, H=HS, R=RC\n"
    "  -z, --clear                 Fully clear the device (program & config).\n"
    "  -Z NN, --eeprom=NN          EEPROM set to NN, NN must follow 'z' (no spaces)\n"
    "                                only affects 24cXX eeproms, not eeprom on PIC.\n"
#if 0
    #ifdef __MSDOS__
    "  -l DELAY, --loop-delay1=DELAY\n"
    "                              Delay 1.\n"
    "  -m DELAY, --loop-delay2=DELAY\n"
    "                              Delay 2.\n"
    #endif
#endif
    "  -o FILE, --output=FILE      Write hexfile to output.\n"
    "  -v, --verbose               Be more verbose.\n"
    "  -L, --list-chips            Print a list supported chips & exit.\n"
    "  -V, --version               Print version.\n"
    "  -h, --help                  Print this help message & exit.\n";

void usage(int n, char *s) {
   if (s!=NULL) fprintf(stderr,"%s: %s\n",command, s);
   if (n>0) fprintf(stderr,usagetxt,command);
   exit(n);
}

/* types of verification */
#define FORCE  0x1
#define VERIFY_AFTER   0x2

/* Argument processing functions */
long int shiftNum(char *);
long int shiftFuses(char *);
FILE *shiftFile(const char *, const char *mode, FILE *defaultfp);

int picPC; /* what we think the PIC's pc is right now */

int	progMode= 0 ;/* default: program */

BOOL progUp=0;     /* has the programmer been initialized? */
extern int verify; /* what kinds of verification we do */
extern int prog_w,
          read_w;  /* total programmed and read words */
int errors = 0;    /* how many programming errors */
BOOL fuses_done=0; /* if commandline fuses, skip from hexfile */

/* fuses */
#define WDT_FUSE 0x04  /* watchdog timer */
#define PUT_FUSE 0x08  /* power-up timer */
#define CP_FUSE  0x10  /* code protect */
#define FUSE_MASK 0x1F /* only these bits are implemented */

/* programming routines */
void readPicTools(FILE *);
void readIntel(FILE *, int format);
void readEEIntel(FILE *fp,int format);
void readBinary(FILE *fp, char *fname);
void write_output(FILE *fout, int format);
void init_to_value(const pic_instr_t zval) ;

unsigned buf_alloc(pic_instr_t **bufp,const int maxsize, const pic_instr_t initcell) ;

#ifdef __MSDOS__
extern int loopd1,loopd2;
#endif

static
struct option longopts[] =
{
  { "verbose",     0, 0, 'v' },
  { "version",     0, 0, 'V' },
  { "chip",        1, 0, 'T' },
  { "verify",      1, 0, 'a' },
  { "help",        0, 0, 'h' },
  { "output",      1, 0, 'o' },
  { "id",          1, 0, 'i' },
  { "fuses-val",   1, 0, 'c' },
  { "fuses",       1, 0, 'C' },
  { "intel16",     1, 0, 'y' },
  { "intel8",      1, 0, 'x' },
  { "binary",      1, 0, 'b' },
  { "clear",       0, 0, 'z' },
  { "eeprom",      1, 0, 'Z' },
  { "pictools",    1, 0, 'p' },
  { "list-chips",  0, 0, 'L' },
  { 0, 0, 0, 0 }
};

typedef unsigned char BYTE;
BOOL have_fuses=0, have_id=0;
pic_instr_t *prog_mem=NULL;
pic_instr_t *data_eeprom=NULL;
pic_instr_t pic_id[4] = { 0,0,0,0 };
unsigned fuses=0x3FFF;

int main(int largc, char *largv[])
{
    int opt,format, outp, i;
    WORD zval=0;
    FILE *fp;

    verbose = 0;
    outp=0; format=IHX8M;
    command=largv[0];
    set_progpath(largv[0]);
    opterr=0; /* disable error messages in getopt() */
    read_w=0;
    prog_w=0; 
    
    while ( (opt=getopt_long(largc, largv, "o:l:m:vVT:ah:y:x:zZ:p:b:FWLi:c:C:", longopts, 0)) != -1  ) {
      loptarg=optarg;
      /* fprintf(stderr,"option=%c (%d/%c)  [%s]\n",opt,opt,optopt,optarg); */
      switch(opt) {
      case 'V':
	printf("%s: Version %s\n",command,PROGVERS);
	break;
      case 'v':
	verbose ++;
	if(verbose > 1) { p84_verbose ++; i2c_debug++; } 
	break;
      case 'Z':
	zval=shiftNum("eeprom reset value");
	init_to_value(zval);
      case 'z':
	if (opt == 'z') zval=0;
	init_to_value(zval);
	break;
      case 'o': outp=1;
	fp = shiftFile("output file","w",stdout);
	if (fp) {
	  write_output(fp,format);
	  if (fp!=stdout) fclose(fp);
	}
	break;
      case 'y':
      case 'x':
	format= opt=='x' ? IHX8M : IHX16;
	fp = shiftFile("hex intel format file","r",stdin);
	if (chip_p->type==PIC) {
	  readIntel(fp,format);
	} else {
	  if (format==IHX8M) readIntel(fp,IHX8D); 
	  else usage(1,"No intel hex-16 format for eeprom :(, only Intel hex8 :)");
	}
	fclose(fp);
	break;
      case 'p':
	format=PICTOOL;
	if (chip_p->type==PIC) {
	  fp = shiftFile("pictools format file","r",NULL);
	  readPicTools(fp);
	  fclose(fp);
	} else usage(1,"No pictools format for eeprom :(, only Intel hex :)");
      case 'b':
	format=IHX8M;
	fp = shiftFile("binary file","r",NULL);
	if (fp) readBinary(fp, loptarg);
	fclose(fp);
	break;
      case 'i':
	if (chip_p->type==PIC) {
	  for(i=0; i<4; i++) pic_id[i] =  shiftNum("id number");
	  /* fprintf(stderr,"%d %d %d %d\n",id[0],id[1],id[2],id[3]);
	     exit(0); return 0; */
	  have_id=1;
	} else usage(1,"No program id in eeprom");
	break;
      case 'c':
	if (chip_p->type==PIC) {
	  fuses = shiftNum("configuration word / fuses");
	  have_fuses=1;
	} else usage(1,"No fuses in eeprom");
	break;
      case 'C':
	if (chip_p->type==PIC) {
	  fuses = shiftFuses("configuration word / fuses");
	  /* fprintf(stderr, "main.cp=%s 0x%04x\n", cp,f); */
	  have_fuses=1;
	} else  usage(1,"No fuses in eeprom");
	break;
	
      case 'h': usage(1,NULL);
	break;
      case 'T':{
	int c = -1;
	int ctp = -1;
	if (tolower( *loptarg )== 'h') c= -1;
	else if (tolower( *loptarg )== 'a') c= 0;
	else c = shiftNum("chip type");
	ctp = set_chiptype(c);
	if (ctp<0) usage(0,"no chiptype requested ");
	if (chip_p->type==PIC) {
	  buf_alloc(&prog_mem,chip_p->prog_size,INVALID_DATA);
	  buf_alloc(&data_eeprom,chip_p->eeprom_size,INVALID_DATA);
	} else if (chip_p->type==EEPROM) 
	  buf_alloc(&data_eeprom,chip_p->eeprom_size,INVALID_DATA);
      }
      break;
      case 'a':
	verify |= VERIFY_AFTER;
	break;
      case 'F':
	verify |= FORCE;
	break;
      case 'W': 
	/* default is only program if newbyte != oldbyte */
	verify &= ~FORCE;
	break; 
      case 'L':
	printListSupported();
	return 0;
      case '?':
      default: {
	char txt[64+strlen(largv[optind-1])];
	sprintf(txt,"unknown option \"%s\"\n", largv[optind-1]);
	usage(1, txt);
      }
      }
    }
    
    if (largc < 2) usage(1,"");
    
    
#ifdef __MSDOS__
    exit(0);
#endif
    return 0;

}

/* Hex  data utilities */

void write_dataprog(FILE *fout, int format, pic_instr_t *dbuf, 
		    pic_instr_t saddr, int sz, int step) {
  int i,last;
  pic_instr_t *bufp=dbuf;
  last= (sz/step)*step;
  for (i=0; i<last ; i +=step) {
    write_hex_record(fout, step, i+saddr, bufp, format);    
    bufp += step;
  }
  if (last<sz)
    write_hex_record(fout,sz-last , last+saddr, dbuf, format);
}

void write_output(FILE *fout, int format) {
  if (verbose) fprintf(stderr," format=%d\n",format);
  if (chip_p->type==PIC) {
    write_dataprog(fout,format,prog_mem,0,chip_p->prog_size,8);
    if (have_id) 
      write_hex_record(fout, 4, picid_addr, pic_id, format);
    if (have_fuses  && ! fuses_done )
      write_hex_record(fout, 1, fuse_addr, &fuses, format);
    write_dataprog(fout,format,data_eeprom,data_addr,chip_p->eeprom_size,8);
  } else if (chip_p->type==EEPROM) {
    write_dataprog(fout,format,data_eeprom,0,chip_p->eeprom_size,8);
  }
  fprintf(fout,":00000001FF" HEX_EOL); /* end record */
}

unsigned buf_alloc(pic_instr_t **bufp,const int maxsize, const pic_instr_t initcell) {
  /* allocate memory buffer of maxize to *bufp, 
     initialize to init_cell,
     return 0 or size allocated
  */
  int bufsz=0;
  if (*bufp) {
    free(*bufp); 
    if (verbose) printf(" buffer freed\n");
    *bufp=NULL; 
  }
  if (! *bufp) {
    *bufp=calloc(maxsize,sizeof(pic_instr_t)); 
    if (verbose) printf(" buffer allocated 0x%x*%x\n",maxsize,sizeof(pic_instr_t));
  }
  if (! *bufp) {
    usage(0,"Can not allocate memory for data/program buffer");
  } else {
    int i;
    if (verbose && 0 ) 
      printf(" buffer alloc 0x%x*%x (%d*%d)\n",
	     maxsize,sizeof(pic_instr_t),maxsize,sizeof(pic_instr_t));
    for (i=0; i<maxsize; i++) (*bufp)[i]=initcell;
    bufsz=maxsize;
  }
  return bufsz;
}
	   
void readBinary(FILE *fp, char *fname) {
  int ch, cnt=0, bufcnt=0;

  if (chip_p->type==PIC) {
    while ( (ch=fgetc(fp)) !=EOF) {
      if (bufcnt<chip_p->prog_size) {
	if (cnt&1) prog_mem[bufcnt] |= (ch<<8)&0xff00;
	else prog_mem[bufcnt] = ch&0xff;
      } else if (bufcnt>=picid_addr && bufcnt< picid_addr+4) {
	if (cnt&1) pic_id[bufcnt-picid_addr] |= (ch<<8)&0xff00;
	else pic_id[bufcnt-picid_addr] = ch&0xff;
      } else if (bufcnt==fuse_addr) {
	if (cnt&1) fuses |= (ch<<8)&0xff00;
	else fuses = ch&0xff;
      } else if (bufcnt>=data_addr) {
	if (cnt&1) data_eeprom[bufcnt] |= (ch<<8)&0xff00;
	else data_eeprom[bufcnt] = ch&0xff;
      }
      if (cnt&1) bufcnt++;
      cnt++;
    }
  } else if (chip_p->type==EEPROM) {
    while ( (ch=fgetc(fp)) !=EOF) {
      if (cnt<chip_p->eeprom_size) data_eeprom[cnt] = ch&0xff;
      cnt++;
    }
  }
  if (verbose) fprintf(stderr,"Read %d bytes into buffer\n",cnt);
}

#if 0
void readEEIntel(FILE *fp,int format) {
    char buf[512];
    unsigned cl, ll, bl, bh, base, type;
    int len;
    BYTE code_buf[32];
    int i;
    int addrmax = chip_p->eeprom_size;

    //if (EEWrThru) addrmax=2048; /* the 24lc16 programmed from 16x84 */

    while (fgets(buf, 512, fp)) {
	if (verbose)  fprintf(stderr,"--- read <%s>\n",fixbuf_crlf(buf));
	if (buf[0]!=':') { /* print bad line */
	    continue;
	}
	sscanf(buf+1,"%02x%02x%02x%02x",&ll,&bh,&bl, &type);
	if (ll == 0) continue; /* avoid processing zero length lines */
	len = ll; base = (bh<<8) + bl;
	if (base <= addrmax) {
	  for (i=0; i<len; i++) {
	    sscanf(buf+9+i*2,"%02x",&cl);
	    code_buf[i]= cl;
	  }
	  /* do not write beyond end of eeprom */
	  if (len+base>addrmax) len=addrmax-base;
	  if (len>0) {
	    if (verbose) 
	      fprintf(stderr,
		      "(ee) Saving %d bytes at addr 0x%04x\n", len, base);
	    for(i=0; i< len-1 ; i+=2 )
	      databuf[(i+base)/2]= 
		((code_buf[i+1]<<8)&0xff00) | (code_buf[i]&0xff);
	    if (len&1 )
	      databuf[(len+base)/2+1]=  (code_buf[len-1]&0xff);
	  }
	}
	if (type == 1) break;
    }
}
#endif

void init_to_value(const pic_instr_t zval) {
  /* allocate buffer, and initialize to "zval" */
  int cnt;
  if (chip_p->type==PIC) {
    //databuf_alloc(0x2800,0x3fff);
    for (cnt=0; cnt<chip_p->prog_size; cnt++) prog_mem[cnt]=zval;
    for (cnt=0; cnt<chip_p->eeprom_size; cnt++) data_eeprom[cnt]=zval;
  } else if (chip_p->type==EEPROM) {
    //databuf_alloc((chip_p->eeprom_size+1)/2,0x0);
    for (cnt=0; cnt<chip_p->eeprom_size; cnt++)
      data_eeprom[cnt]=((zval<<8)&0xff00)|(zval&0xff);
  }
}

void readIntel(FILE *fp, int format)
{
    char buf[512];
    unsigned ch, cl, ll, bl, bh, base, len, type;
    pic_instr_t code_buf[32];
    int i;

    //databuf_alloc(0x2800,0x3fff);

    while (fgets(buf, 512, fp)) {
	if (verbose) fprintf(stderr,"--- read <%s>\n",fixbuf_crlf(buf));

	if (buf[0]!=':') { /* print bad line */
	    continue;
	}
	sscanf(buf+1,"%02x%02x%02x%02x",&ll,&bh,&bl, &type);
        if (format==IHX16 || format==IHX8D) {
	  len = ll; base = (bh<<8) + bl;
	} else { /* IHX8M */
	  len=  (ll) /2; base= ((bh<<8) + bl) /2;
	}
	if (ll == 0) continue; /* avoid processing zero length lines */
	if (base < chip_p->prog_size) {
	  /*** normal code ***/
	  for (i=0; i<len; i++) {
	    sscanf(buf+9+i*4,"%02x%02x",&cl, &ch);
	    code_buf[i]= format==IHX16 ? (cl<<8)+ch: (ch<<8)+cl;
	  }
	  if (verbose) fprintf(stderr,"(p) Read %d words at addr 0x%04x\n",len, base);
	  /* some hex files have adresses at addr==max! */
	  if (len+base>chip_p->prog_size) len=chip_p->prog_size-base-1;
	  for (i=0; i<len; i++) prog_mem[i+base]=code_buf[i];
	} else if (base == picid_addr ) {
	  /*** picid ***/
	  for (i=0; i<len; i++) {
	    sscanf(buf+9+i*4,"%02x%02x",&cl, &ch);
	    if (i<4) pic_id[i]= format==IHX16 ? (cl<<8)+ch: (ch<<8)+cl;
	  }
	  if (verbose) fprintf(stderr,"(id) 0x%02x 0x%02x 0x%02x 0x%02x\n",pic_id[0],pic_id[1],pic_id[2],pic_id[3]);
	  have_id= len>0;
	} else if (base == fuse_addr) {
	  /*** fuse ***/
	  sscanf(buf+9,"%02x%02x",&cl, &ch);
	  fuses= format==IHX16 ? (cl<<8)+ch: (ch<<8)+cl;
	  have_fuses=1;
	  if (verbose) fprintf(stderr,"(fuses) 0x%04x\n",fuses);
	} else if (base >= data_addr && base < data_addr+chip_p->eeprom_size) {
	  for (i=0; i<len; i++) {
	    if (format==IHX8D) {
	      sscanf(buf+9+i*2,"%02x",&cl);
	      code_buf[i]= cl;
	    } else {
	      sscanf(buf+9+i*4,"%02x%02x",&cl, &ch);
	      code_buf[i]= format==IHX16 ? ch : cl;
	    }
	  }
	  if (verbose) 
	    fprintf(stderr,"(d) Read %d words at addr 0x%04x\n",len, base);
	  
	  /* do not write beyond end of eeprom */
	  if (len+base>chip_p->eeprom_size) len=chip_p->eeprom_size-base;
	  for (i=0; i<len; i++) data_eeprom[i+base]=code_buf[i];
	}
	if (type == 1) break;
    }
}

void readPicTools(FILE *fp)
{

    char buf[512];
    unsigned code_addr = 0;
    int i;

    fuses = 0x3FFF;

    while (fgets(buf, 512, fp)) {
	switch(*buf) {
	case 0:
	case '\n':
	case '\r':
	case '#':
	    break;
	case 'I':
	    if (sscanf(buf+1, "%i %i %i %i",
		    &pic_id[0], &pic_id[1], &pic_id[2], &pic_id[3]) != 4) {
		fprintf(stderr,"error reading ID numbers\n");
		exit(2);
	    }
	    have_id = 1;
	case 'A':
	    sscanf(buf+1, "%x", &code_addr);
	    break;
	case 'D':
	    {
	    WORD code_buf[32];
	    int code_count;
	    char *cp;

	    code_count = strtol(buf+1, &cp, 10);
	    if (cp == buf+1) {
		 fprintf(stderr,"error reading data byte count\n");
		 exit(2);
	    }
	    for (i=0; i<code_count; i++)
	        code_buf[i] = (WORD) strtol(cp, &cp, 16);

	    for (i=0; i<code_count; i++) prog_mem[i+code_addr]=code_buf[i];
	    code_addr += code_count;
	    break;
	    }
	case 'T':
	    if (atoi(buf+1) != 84) {
		fprintf(stderr, "I'm a 16C84 programmer, but this file as %s",
		    buf);
		exit(2);
	    }
	    break;
	case 'W':
	    have_fuses = 1;
	    fuses &= ~ WDT_FUSE;
	    if (atoi(buf+1)) fuses |= WDT_FUSE;
	    break;
	case 'U':
	    have_fuses = 1;
	    fuses &= ~ PUT_FUSE;
	    if (atoi(buf+1)) fuses |= PUT_FUSE;
	    break;
	case 'P':
	    have_fuses = 1;
	    fuses &= ~ CP_FUSE;
	    if(atoi(buf+1)) fuses |= CP_FUSE;
	    break;
	case 'C':
	    i = atoi(buf+1);
	    have_fuses = 1;
	    fuses = ( fuses & ~3 ) | ( atoi(buf+1) & 3 );
	    break;
	case 'S':
	    fprintf(stderr,"[ignoring pictools file checksum]");
	    break;
	default:
	    fprintf(stderr,"warning: unrecognized line: %s", buf);
	    break;
	}
    }

}


/* Arg parsing functions */


long int shiftNum(char *what)
{   char *end;
    long int val;

    if (loptarg !=NULL) {
	while ( *loptarg==' ')  loptarg++;
	if (*loptarg==',') loptarg++;
    }
    if ((loptarg==NULL) ||  !*loptarg) {
	usage(1,"arglist ends abruptly\n");
    }

    val = strtol(loptarg, &end, 0);
    if (loptarg == end) {
	char txt[128];
	sprintf(txt, "expecting %s, got \"%s\"", what, loptarg);
	usage(1,txt);
    }
    loptarg=end;
    return val;
}

long int shiftFuses(char *what)
{
    long int f;
    if ((loptarg==NULL) || (*loptarg == '\0')) {
	usage(1, "arglist ends abruptly");
    }
    if (chip_p->chiptype!=1684) {
	fprintf(stderr, "Error: symbolic fuses only supported for 16x84 devices\n");
	exit(3);
    }
	f=0x3fe0|CP_FUSE|1;
	while (*loptarg != 0) {
		switch (tolower(*loptarg)) {
		 case 'f': /* dummy */ ; break;
		 case 'u': f |= PUT_FUSE; break;
		 case 'w': f |= WDT_FUSE; break;
		 case 'c': f &= ~CP_FUSE; break;
		 case 'l': f = f&0xfffc;  break;
		 case 'x': f = (f&0xfffc)|1;  break;
		 case 'h': f = (f&0xfffc)|2;  break;
		 case 'r': f = (f&0xfffc)|3;  break;
		 case ',': 
		 case ' ': break; /* skip */
		 default: /* skip / continue */
		   break;
		}
		loptarg++;
	}
    if (*loptarg != '\0') {
	char txt[128];
	sprintf(txt, "expecting %s, got \"%s\"",  what, loptarg);
	usage(1,txt);
    }
    return f;
}

FILE *shiftFile(const char *what, const char *mode, FILE *defaultfp)
{
    FILE *fp;
    extern char *strerror();

    if ((loptarg==NULL) ||  !*loptarg) {
	usage(1,"arglist ends abruptly");
    }

    if (defaultfp && !strcmp(loptarg,"-")) fp=defaultfp;
    else {
      fp = fopen(loptarg, mode);
      if (!fp) {
	char txt[128];
	sprintf(txt, "can't open %s %s: %s",
		what, loptarg, strerror(errno));
	usage(2,txt);
      }
    }
    return fp;
}


