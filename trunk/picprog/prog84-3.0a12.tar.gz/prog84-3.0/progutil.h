#ifndef _PROGUTILH
#define _PROGUTILH
/*
 * progutil.h
 */

/* output formats */
enum {
  IHX8M,
  IHX16,
  IHX8D,
  PICTOOL,
  BINARY,
  BLANK_CHECK
};

/* org mode */
typedef enum {
  O_NONE,
  O_PROGRAM,
  O_REGFILE,
  O_EDATA
} org_mode_t ;

enum { INVALID_DATA= 0xfffff };

#ifdef __MSDOS__
typedef unsigned long pic_instr_t;
# define HEX_EOL "\n"
#else 
typedef unsigned int pic_instr_t;
/* make DOS format hex file, so it even can be read by dos programs :) */
# define HEX_EOL "\r\n"
#endif

extern int EEWrThru;
extern int verify;

void write_hex_record(FILE *fp,
                           int reclen, /* length (in words) */
                           int loc, /* address */
                           pic_instr_t *data, /* pointer to word data */
                           int format) /* IHX8M or IHX16 */ ;

void dumphexEEData(FILE *, WORD, WORD, int format);

void programEEIntel(FILE *fp,int format);
void ResetEE(WORD val);

/* util's for PIC write-"thru"-mode */
/* void programEEIntelThru(FILE *fp); */
void ClockPulses(int clks, char *s) ;
int GetAck(int dcmp);
void SendData(int val, int contdata, int nclks) ;
int RecvData(int nclks);
void ThruSendaddr(int comm, int addr);


char *fixbuf_crlf(char *buf) ;

#endif
