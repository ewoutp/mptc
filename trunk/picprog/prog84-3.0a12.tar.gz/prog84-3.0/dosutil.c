/* (C) 1999 Frank Damgaard - GNU Copyleft */
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <string.h>
#include <time.h>

#ifndef DOSTEST
#include "prog84.h"
#else
int verbose=0, p_loopcnt=0;
struct lp_io {
  int  base;  /* base I-O address */
};

struct lp_io lpb = { 0x3ee };
#endif

#ifdef __MSDOS__
#define CPU8086 1
#define CPU80286 2
#define CPU80386 3
#define CPU80486 4

/* determine cpu type for delay loop */
int cputype() {
 int dummy=0;
 /* ^ program crashes withput a variable here , weird code generation
      with Turbo C++ compiler */
 asm {
   mov dx,CPU8086;
   push sp ;
   pop  ax ;
   cmp sp,ax ;
   jne out;
   mov dx,CPU80286 ;
   pushf ;
   pop ax;
   or ax,0x4000;
   push ax;
   popf;
   pushf;
   pop ax;
   test ax,0x4000;
   je out;
   mov dx,CPU80386;
   /* DB 0x66 INDICATES x386 EXTENDED INSTRUCTION */
   DB 0x66 ;
   mov bx,sp;
   db 0x66, 0x83, 0x4e, 0xfc;
   db 0x66;
   pushf;
   db 0x66;
   pop ax;
   db 0x66;
   mov cx,ax;
   db 0x66, 0x35, 0x0;
   db 0x0, 0x4, 0x0;
   db 0x66;
   push ax;
   db 0x66;
   popf
   db 0x66;
   pushf;
   db 0x66;
   pop ax;
   db 0x66,0x25,0x0;
   db 0x0,0x4,0x0;
   db 0x66,0x81,0xe1,0x0;
   db 0x0,0x4,0x0;
   db 0x66;
   cmp ax,cx;
   je not486;
   mov dx,CPU80486;
   }
not486:
 asm {
   db 0x66;
   push cx;
   db 0x66;
   popf
   db 0x66;
   mov sp,bx;
 }
 out:
 dummy=_DX;
 if (dummy<=1) return 86;
 else return dummy*100+86;
}
#endif


static char **argvl=NULL;
static char *currarg=NULL;
static int maxargc;
static int argcl = -1;
char *optarg = NULL;
int  optopt=0,opterr=0;

/* simple getopt() */

int getopt(int argc, char *argv[], char *optstring) {
  char *cp;

  if ( argcl == -1) {
    maxargc=argc; 
    argvl=argv; 
    argcl=0;
  }

    if (currarg==NULL || *currarg=='\0') {
      if (++argcl>=maxargc) return -1;
      currarg=argvl[argcl];
      if (*currarg != '-') return -1;
      currarg++;
    }
    optopt=*currarg;
    if (*currarg=='\0') return '?';
    if ( (cp=strchr(optstring,*(currarg++))) ==NULL ) return '?';
    if (*(cp+1)==':') {
      if (*currarg!='\0') { optarg=currarg; currarg=NULL; }
      else {
	if (++argcl>=maxargc) return '?';
	optarg=argvl[argcl];
	currarg=NULL;
      }
    } else {
      optarg=NULL;
    }
    return *cp;
}

#ifdef __MSDOS__


static int ucpu=-1; /* -1 indicate get cpu type */
static unsigned loopcnt=0;
static unsigned slpcnt1;

void sleep100ns(unsigned  u) {
/* should give a delay of minimum 100ns ! */
   unsigned slpcnt2;
   if (verbose>1) printf(" {sleep %u00ns %u} ",u,loopcnt);
   if (loopcnt==0) return; /* really slow PC */
   else if (loopcnt<=1) {  /* not so slow PC */
      for (slpcnt2=2; slpcnt2<=u; slpcnt2++) ;
   } else /* fast PC */
     for (slpcnt1=1; slpcnt1<loopcnt; slpcnt1++)
      for (slpcnt2=2; slpcnt2<=u; slpcnt2++) ;
}


static void set_loopcnt() {
  char *prg84;
  /* default should give min. 0.1-0.2 usec. delay
     in sleep100ns(1) with K6-300 */
  if (p_loopcnt<0) {
      if (ucpu>=486) loopcnt=12; /* default K6-300 */
      else if (ucpu==386) loopcnt=0; /* default 386 */
      else loopcnt=0; /* default < 386 */
  } else loopcnt=p_loopcnt;
  if (verbose>1) fprintf(stdout," 100ns delay: loop count=%u\n",loopcnt);
}



#if 0
/* some testing, didn't work */
static unsigned long clockcnt() {

  unsigned long l1,l2;
  int ret;
  union REGS regs;
  regs.h.ah=0x00;
  int86(0x1a,&regs,&regs);
  l1= (unsigned) regs.x.dx;
  l2= (unsigned) regs.x.cx & 0xf + ((regs.x.cx&0xf0)>>4)*10;
  return (l2<<16) + l1;

}
#endif


/* usleep() is needed */

/* this needs improvement .... !! */
void usleep(unsigned long usec) {

 if (ucpu<0)  {
   /* first time  usleep called, s� set delay from cputype  */
    if (verbose>1) fprintf(stderr,"testing cpu...\n ");
    ucpu=cputype();
    if (verbose) {
      fprintf(stderr,"detected cpu%c=80%d\n",ucpu<486?'=':'>',ucpu);
    }
    set_loopcnt();
 }
 if (verbose>2) fprintf(stderr,"usleep=%lu",usec);
 if (ucpu<486 && usec<2000UL) sleep100ns( (unsigned) (usec*10));
 else if (ucpu>=486 && usec<50000UL) {
      /* use this for smaller delays , since delay() is
	 broken on faster CPU's ... */
      int i;
      for (i=1; i<=10; i++) sleep100ns( (unsigned) usec );
 } else {
   /* >= 2ms, so call delay(usec/1000) */
   unsigned ms;
   ms = (unsigned) usec/1000;
   if (ms<1) ms=1;
   if (ms>5000) ms=5000; /* so long delays are not needed , must be error */
   if (verbose>2) fprintf(stderr," delay(%u)",ms);
   delay(ms);
 }
 if (verbose>1) fprintf(stderr,"..\n");
}

#endif

/* test : */
#ifdef DOSTEST

static unsigned long rtcclk() {
  unsigned s,m;
  int ret;
  union REGS regs;
  regs.h.ah=0x02;
  int86(0x1a,&regs,&regs);
  m= (unsigned) (regs.h.cl & 0xf) + (regs.h.cl>>4)*10;
  s= (unsigned) (regs.h.dh & 0xf) + (regs.h.dh>>4)*10;
  /* printf(" %02x %02x - %d %d\n",regs.h.cl,regs.h.dh,m,s); */
  return s+m*60;

}


static int looptest1(unsigned looptst) {
   int s1,s2,s;
   unsigned lc;
   loopcnt=looptst;
   s1=rtcclk(); /* resort to real time / cmos clock */
     for (lc=0; lc< 1000; lc++) { /* 1 s */
       sleep100ns(10000); /* 1 ms */
     }
     s2=rtcclk();
     s=s2-s1; if (s<0) s+=3600;
     /*  test=10
	 1 s = loopcnt * N   => loopcnt = 1/N
	 s2-s1 = test * N      => N= (s2-s1)/test
	 =>  loopcnt =  test/(s2-s1)
     */
     loopcnt=s<1?loopcnt:loopcnt/s;
     if (verbose>1)
       printf("  ::   rtc clock: %d -> %d= %d  (loopcnt old=%u new=%u)\n",
	      s1,s2,s,looptst,loopcnt);
     return s;
}

void main(int argc, char **argv) {
  int c;
  int s1,s2,s;
  unsigned lc,l;
  unsigned lcnt=0;

  ucpu=cputype();
  printf(" Detected cpu%c=80%d\n",ucpu<486?'=':'>',ucpu);
  if (ucpu<=386) {
    printf(" Try with \"SET PROG84=0\" or \"SET PROG84=1\"\n");
  }
  while (-1 != (c=getopt(argc, argv, "acvsul:"))) {
   switch (c) {
     case 'l':
	   if (verbose>1) printf(" [ %c %s] \n",c,optarg);
	   if ( 1!=sscanf(optarg,"%u",&l)) l=1;
	   loopcnt=l; p_loopcnt=l;
	   goto loopfinal ;
     case 'u':
	   set_loopcnt(); s1=rtcclk(); lcnt=loopcnt;
	   for (l=0; l<500; l++) usleep(10000L);
	   s2=rtcclk(); s=s2-s1;
	   if (s<0) s+=3600;
	   printf(" Measured %u seconds with 500 x ( 10000 usec)\n",
		    s2-s1,lcnt);
	  break;
     case 's':
	   set_loopcnt(); s1=rtcclk(); lcnt=loopcnt;
	   for (l=0; l<10; l++) s=looptest1(lcnt);
	   s2=rtcclk(); s=s2-s1;
	   if (s<0) s+=3600;
	   printf(" Measured %u seconds with 10 x (loopcnt=%u)\n",
		    s2-s1,lcnt);
	  break;
     case 'a': case 'c':
	   lcnt=0;
	   printf(" Calibrating 100 ns delay loop please wait...\n",c);
	   s=looptest1(lcnt);
	   if (s>=2) {
	     printf(" Measured %d seconds, so this a slow PC;\n"
		    " sleep100ns() should only be a 'dummy' function call\n");
	     loopcnt=0;
	   } else {
	     for (lcnt=1; s<=3 && lcnt<10000 ; lcnt*=5){
	       printf(" Measured over < %u seconds, so trying with longer "
		      "period, approx. %d..%d sec.\n",s+1,s,s*10+1);
	       s=looptest1(lcnt);
	     }
	   }
     loopfinal:
	   lcnt=loopcnt;
	   if (verbose) printf(" loopcnt=%u\n",lcnt);
	   printf(" Mesured %d seconds, "
		  "so final test should be approx. 10 seconds...\n",s);
	   s=looptest1(lcnt*10);
	   printf(" Measured %d seconds with loopcnt=%u\n",s,lcnt);
	   printf(" Use \"SET PROG84=%u\" before running prog84/dump84\n",lcnt);
       break;
     case 'v':
	  verbose++;
	  break;
     default:
	printf(" [error, unknown option: %c ] ",c);

   }
  }

}
#endif
