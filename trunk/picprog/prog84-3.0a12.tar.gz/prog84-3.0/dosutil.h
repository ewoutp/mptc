/* (C) 1999 Frank Damgaard  - GNU CopyLeft
 */

#ifndef _DOSUTILH
#define _DOSUTILH

void sleep100ns(unsigned );
void usleep(unsigned long);
int getopt(int argc, char **argv, char *optstring) ;
int cputype();
extern char *optarg;
extern int optopt,opterr;
#else
#endif

