/* header for anything that wants to use the 16C84's serial programming mode */
#ifndef PROG84_H
#define PROG84_H
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#ifndef __MSDOS__
#include <unistd.h>
#include <sys/time.h>
#endif
#include "io_ports.h"


#ifndef	EXTERN
#define	EXTERN extern
#endif

/* MSDOS needs SLEEP100ns() , linux (and other?) can leave it empty */
#ifdef __MSDOS
# define SLEEP100ns(usec)  sleep100ns(usec)
#else
# define SLEEP100ns(usec)
#endif

/***
 *** Externally visible variables & functions
 ***/

/*** VARIABLES ***/

    /***
     *** Bit indicators for the various control & feedback signals.
     *** See lp_io for what a bit indicator is.
     ***/
extern int p_power, p_mclr, p_vpp2, p_vpp3, 
           p_clock, p_data, p_clock_f, p_data_f;
extern int p_loopcnt, p_progtype, p_no_power_C4C8;

    /*** lp_io control structure ***/
extern struct lp_io lpb;

    /*** name of file to read pin assignments from; defaults to lp_cfg ***/
extern char *cfg_file;

    /*** path to the called program - if possible */
extern char *progpath;

    /*** set this to nonzero for copious output ***/
extern int p84_verbose;
EXTERN int verbose;
EXTERN int emulate_write;

/*** FUNCTIONS ***/

void set_progpath(char *prog) ;

    /***
     *** set up and shut down the programmer, as well as the software layers
     *** under this (lpb_cfg_read, open_io(), etc.)
     ***/
void progSetup();
void progShutdown(); /* powers down */
void power_and_reset();

    /*** simple hardware test sequence. called by progSetup().
     *** returns non-zero on problem.
     ***/
int testHW();

/*** Routines to clock some bits through the chip serially. */
    /*** send bits through the '84 */
unsigned int pipeBits(unsigned int, int);

    /*** send bits, confirm, exit on error ***/
void xPipeBits(unsigned int, int);

    /*** send command & 14 data bits ***/
void genericWrite(int, unsigned int);

    /*** send command, then read 14 data bits ***/
unsigned int genericRead(int);

    /*** print a list of supported devices ***/
void printListSupported();

/* ************************************************************************ */
/* Defines for the descriptive programmer.                                  */

/* MICROCHIP'S SERIAL COMMANDS */
#define SC_LOADCFG	 0	/* DATA */
#define SC_CMD1		 1	/* used to clear protection */
#define SC_LOADPROG	 2	/* DATA */
#define SC_LOADDATA	 3	/* DATA */
#define SC_READPROG	 4	/* DATA */
#define SC_READDATA	 5	/* DATA */
#define SC_INCREMENT	 6
#define SC_CMD7		 7	/* used to clear protection */
#define SC_PROGRAM	 8
#define SC_ERASEPGM	 9
#define SC_PARALLEL	10  /* not used */
#define SC_ERASEDATA	11
#define SC_CMD11	11	/* ??? */
#define SC_ENDPROGRAM   14      /* needed for 16c6x/7x/9xx programming */

/* Bit-twiddling macros, for convenience */
#define SET(bitname, value) lpb_write(&lpb, p_ ## bitname, value)
/* Before using GET on new data from port, use REFRESH to read port !! 
   FLUSH may not always have appropiate delay before reading port */
#define GET(bitname) lpb_test(&lpb, p_ ## bitname)
#define FLUSH do{ lpb_flush(&lpb); SLEEP100ns(1); lpb_refresh(&lpb); } while(0)
/* old: #define FLUSH do{ lpb_flush(&lpb); lpb_refresh(&lpb); } while(0) */
#define REFRESH do { lpb_refresh(&lpb); } while(0)

/* Commands that write */
#define loadConfiguration(cfg) genericWrite(SC_LOADCFG, cfg)
#define loadProg(data)         genericWrite(SC_LOADPROG, data)
#define loadData(data)         genericWrite(SC_LOADDATA, data)

/* Commands that read */
#define readProg()	genericRead(SC_READPROG)
#define readData()	genericRead(SC_READDATA)

/* Commands that neither read nor write */
#define incAddr()	xPipeBits(SC_INCREMENT, 6)
#define doProgram()	{xPipeBits(SC_PROGRAM, 6); usleep(15000UL); prog_w++; }
#define endProgram()    xPipeBits(SC_ENDPROGRAM, 6)

/* EEprom/i2c defines */
/* actually it should be named EE_ACK/EE_NOACK .*/
#define I2C_ACK 1
#define I2C_NOACK 0
#define EE_CTRL_WR 0xa0
#define EE_CTRL_RD 0xa1

/* EEprom/i2c Bit-twiddling macros, for convenience */
#define SET(bitname, value) lpb_write(&lpb, p_ ## bitname, value)
#define GET(bitname) lpb_test(&lpb, p_ ## bitname)


/*#define I2C_SET(ctrl,dat)  SET(clock,ctrl) ; SET(data,dat) ;  FLUSH */
#define I2C_SET(ctrl,dat)  i2c_out(ctrl,dat)
#define I2C_GET()   lpb_test(&lpb, p_data_f)
#define I2C_DEBUG(x)  if (i2c_debug) (x)


typedef char BOOL;
#ifdef __MSDOS__
typedef unsigned WORD;
typedef long WORD32;
#else
typedef unsigned short WORD;
typedef int WORD32;
#endif

/* chip types for the chips[] array in prog84.c                       */
enum { noPICtype=0, PIC, EEPROM };
/* enum { noPICtype, PIC16x84, PIC16x64, EE24C16, EE24C08, EE24C65 } ; */
enum { FL_ENDPROGRAM=1, FL_NO_ERASABLE=2, FL_CTRLADDR=0x10, FL_2ADDR=0x20,
	FL_PIC12SERIES=0x8000 } ;

enum {  
  picid_addr = 0x2000, /* start of picid address */
  fuse_addr  = 0x2007, /* start of fuse address */
  data_addr  = 0x2100  /* start og eeprom data in PIC */
};

typedef struct  {
  char *name;         /* textual chip name e.g. 16f84         */
  WORD chiptype;      /* numeric chip name e.g. 1684          */
  BOOL type;          /* chip types as above                  */
  WORD prog_size;     /* code space in words                  */
  WORD eeprom_size;   /* data space in bytes                  */
  WORD dev_id,dev_mask; /* device ID and ID mask              */
  WORD extraflags ;   /* bits set by FL_xxxxxxx */
  WORD page_size;     /* maximum EEPROM page write size       */
} chip_info;

extern chip_info *chip_p;
extern int chiptype; 

chip_info * get_chip_p(int chtype) ;
int set_chiptype(int c);

/* I2C for EERPOM */

extern int i2c_debug;

void i2c_start() ;
void i2c_stop() ;
int i2c_sendbyte(unsigned char dat);
unsigned char i2c_readbyte(int ack);
void i2c_seqread(WORD adr, unsigned char *data, int len) ;
unsigned char i2c_read(WORD adr) ;
int i2c_waitack(unsigned int t);
void i2c_pagewrite(WORD adr, unsigned char *data, WORD PageSize) ;
void i2c_write(WORD adr, WORD data) ;


#endif /* PROG84_H */
