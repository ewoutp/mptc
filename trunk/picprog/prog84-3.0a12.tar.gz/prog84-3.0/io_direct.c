/*** (C) 1994-> Wim Lewis and others (Credits file)
 *** I/O primitives for systems which allow direct access to hardware
 *** via inb() / outb()
 ***
 *** this includes the *BSD family, Linux and MS-DOS
 ***
 *** 
 ***
 ***/

#include "io_ports.h"

#ifdef __FreeBSD__
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <machine/cpufunc.h>

static int portio_fd= -1;

void close_io()
{
    close(portio_fd);
}

void open_io(struct lp_io_usage *iot)
{
    portio_fd=open("/dev/io",O_RDWR);
    if (portio_fd <0 ) {
       perror("cannot open /dev/io");
       exit(errno);
    }
}

#endif

#ifdef __linux__
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/io.h>
#include <fcntl.h>

void close_io()
{ /* close not needed, process and permissions die... */ }

void open_io(struct lp_io_usage *iot)
{
  /* give permissions to IO ports ( <= 0x3ff !!) */
  if (ioperm(iot->base,iot->count,1)) {
    fprintf(stderr,"I/O Operation not permitted (must be root!)\n");
    exit(1);
  }

}

#endif


#ifdef __MSDOS__
/* MSDOS - turbo C */
#include <dos.h>

void close_io()
{
   return ; /* dummy - hardware always available to DOS */
}

void open_io(struct lp_io_usage *iot)
{
   return ; /* dummy - hardware always available to DOS */
}

#endif


#ifdef __FreeBSD__
#if 0
/* Some very old stuff , removed 2001-10-30 */
#ifndef inb
#define inb(y) \
    ({ unsigned char _tmp__; \
    asm volatile("inb %1, %0" : "=a" (_tmp__) : "d" ((unsigned short)(y))); \
		_tmp__; })
#endif /* inb */
#ifndef outb
#define outb(x, y) \
    { asm volatile("outb %0, %1" : : "a" ((unsigned char)(y)) ,\
    "d" ((unsigned short)(x))); }
#endif /* outb */
#endif

void out_byte(unsigned int port, unsigned char byte)
{
    outb(port,byte);
}

unsigned char in_byte(unsigned int port)
{
    return inb(port);
}
#endif  /* FreeBSD */

#ifdef __linux__

void out_byte(unsigned int port, unsigned char byte)
{
  outb(byte,port);
}

unsigned char in_byte(unsigned int port)
{
  return inb(port);
}
#endif  /* linux */

#ifdef __MSDOS__

void out_byte(int port, unsigned char byte)
{
    outportb(port,byte);
}

unsigned char in_byte(int port)
{
    return inportb(port);
}


#endif /* MSDOS */
