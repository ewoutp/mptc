/*** (C) 19990127 Frank Damgaard + others
 ***
 *** File: dump84.c
 ***
 *** dumps the content of a 16c84/16f84/24c16
 ***/


#ifdef __MSDOS__
#include "dosutil.h"
#else
#include <unistd.h>
#include <getopt.h>
#endif

#define EXTERN
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "prog84.h"
#include "progutil.h"


void dumpProg(FILE *, WORD, WORD);
void dumpData(FILE *, WORD, WORD);
void dumpCfg(FILE *, short pid, short pfuses);

#define	RESET	1
#define	NORESET	0
pic_instr_t dumphexProg(FILE *, WORD, WORD, BOOL);
void dumphexData(FILE *fput, WORD min_addr);
void dumphexCfg12(FILE *, unsigned, unsigned, pic_instr_t);
void dumphexCfg16(FILE *, unsigned, unsigned);

FILE *shiftFile(const char *what, const char *mode, FILE *defaultfp);

int format;
int blank=1;
pic_instr_t buf[16]; /* should be enough */

void dump_buf(FILE *fout, pic_instr_t buf_count)
{
    int i;
    fprintf(fout,"D%d", buf_count);
    for(i=0; i<buf_count; i++)
	fprintf(fout," %04x", buf[i]);
    fprintf(fout,"\n");
}

char *command;

void usage(int errn, char *txt)
{
   if (txt && strlen(txt)>0) fprintf(stderr,"%s: %s\n",command,txt);
   if (errn>0)
      fprintf(stderr,
              "Usage: %s [options]\n"
              "Dumps the memory contents of a Microchip's PIC MCU or serial EEPROM.\n\n"
              "  -T CHIP, --chip=CHIP        Select CHIP: -1 0 2408 2416 2465 1684 ...\n"
              "  -p, --dump-prog             Dump pic program.\n"
              "  -d, --dump-data             Dump pic/eeprom data.\n"
              "  -f, --dump-fuses            Dump fuses.\n"
              "  -i, --dump-id               Dump id.\n"
              "  -a, --dump-all              Dump all of above.\n"
              "  -x, --intel8                Use intel hex8 format (default).\n"
              "  -y, --intel16               Use intel hex16 format.\n"
              "  -t, --pictools              Use pictool format.\n"
              "  -b, --blank-check           No dump, just blank check.\n"
              "  -l NN, --from=NN            Dump only the first NN positions.\n"
	      "  -o FILE, --output=FILE      Write hexfile to FILE, '-' is stdout.\n"
              "  -v, --verbose               More verbose.\n"
              "  -L, --list-chips            Print a list supported chips & exit.\n"
              "  -V, --version               Print version.\n"
              "  -h, --help                  Print this help message & exit.\n"
              ,command);
        exit(1);
}

// Used: abdfhilLptTvVxy
static
struct option longopts[] =
{
  { "dump-all",    0, 0, 'a' },
  { "dump-fuses",  0, 0, 'f' },
  { "dump-prog",   0, 0, 'p' },
  { "dump-data",   0, 0, 'd' },
  { "dump-id",     0, 0, 'i' },
  { "intel8",      0, 0, 'x' },
  { "intel16",     0, 0, 'y' },
  { "pictools",    0, 0, 't' },
  { "output",      1, 0, 'o' },
  { "help",        0, 0, 'h' },
  { "verbose",     0, 0, 'v' },
  { "version",     0, 0, 'V' },
  { "chip",        1, 0, 'T' },
  { "from",        1, 0, 'l' },
  { "blank-check", 0, 0, 'b' },
  { "list-chips",  0, 0, 'L' },
  { 0, 0, 0, 0 }
};


int main(int argc, char *argv[])
{
    int prog=0,fuses=0,data=0,id=0;
    WORD last_addr=0;
    int opt;
    time_t now;
    char *end;
    FILE *fout;
    
    set_progpath(argv[0]);
    verbose=0; format=IHX8M;
    command = argv[0]; opterr=0;
    fout=stdout;
    
    while((opt=getopt_long(argc, argv, "afpdixythvVT:l:o:bL", longopts, 0)) != -1) {
      switch(opt) {
      case 'a': fuses=data=id=prog=1; break;
      case 'f': fuses=1; break;
      case 'p': prog=1; break;
      case 'd': data=1; break;
      case 'i': id=1; break;
      case 'x': format=IHX8M; break;
      case 'b': format=BLANK_CHECK; break;
      case 'T':
	      {
		int c= (int) strtoul(optarg,&end,0);
		int ctp=set_chiptype(c);
		if (ctp<0) usage(0,"no chip requested ");
		//fprintf(stderr,"requested %s\n",chip_p->name);
	      }
	      break;
      case 'y': format=IHX16; break;
      case 't': format=PICTOOL; break;
      case 'l': last_addr= (WORD) strtoul(optarg,&end,0);
	if (last_addr> 0x1000) usage(1,"length > 0x1000");
	break;
      case 'o': 
	fout = shiftFile("output file","w",stdout);
	break;
      case 'V':
	printf("%s: Version %s\n",command,PROGVERS);
	exit(0);
	break;
      case 'v': 
	verbose ++;
	if(verbose > 1) { p84_verbose ++; i2c_debug++; } 
	break;
      case 'L':
	printListSupported();
	return 0;
      case 'h':
	usage(1,0);
	break;
      default:{
	  char txt[64+strlen(argv[optind-1])];
	  sprintf(txt,"unknown option \"%s\"\n", argv[optind-1]);
	  usage(1, txt);
	}
      }
    }
    
    if ( ! (fuses||data||id||prog) ) {
       usage(1,0);
    }
    progSetup();
    {   
      WORD sz;
      
      if (chip_p->type==EEPROM) sz=chip_p->eeprom_size;
      else sz=chip_p->prog_size;
      if (last_addr==0) last_addr=sz;
      if (last_addr>sz) {
	char txt[20];
	sprintf(txt,"length > 0x%x",sz);
	usage(1,txt);
      }
      if (verbose) fprintf(stderr,"dump last_addr=0x%04x %4x\n",last_addr,sz);
    }
    
    if (format != PICTOOL) {
      if (chip_p->type == PIC) {
	if (chip_p->extraflags&FL_PIC12SERIES) {
	  int i;
	  unsigned cfg;
	  pic_instr_t osccal=0xffff;

	  power_and_reset();
	  cfg = (pic_instr_t) readProg();	/* read fuses */
	  incAddr();				/* PC=0 */
	  if (prog) {
	    osccal = dumphexProg(fout, 0, last_addr, NORESET);
	    if (last_addr != chip_p->prog_size) {
	      for (i=last_addr; i<chip_p->prog_size-1; i++) incAddr();
	      osccal = readProg();
	      incAddr();
	    }
	    if ((osccal & 0xf00) == 0xc00) {
	      fprintf(stderr, "Oscillator calibration value = %u (0x%.2x)\n",
		  osccal & 0xff, osccal & 0xff);
	    } else if (osccal == 0xfff) {
	      fprintf(stderr, "Oscillator calibration value is not set\n");
	    } else if (osccal != 0xffff) {
	      fprintf(stderr, "Oscillator calibration value is incorrect\n");
	    }
	  } else if (id) {
	    for (i=0; i<chip_p->prog_size; i++) incAddr();
	  }
	  if (id || fuses) dumphexCfg12(fout, id, fuses, cfg);
	} else { /* not PIC12 */
	  if (prog) dumphexProg(fout,0, last_addr, RESET);
	  if (id || fuses) dumphexCfg16(fout,id,fuses);
	  if (data)  dumphexData(fout,0);
	}
      } else if (data) {
	dumphexEEData(fout,0,last_addr,format);
      }
      if (format != BLANK_CHECK)
	fprintf(fout,":00000001FF" HEX_EOL); /* end record */
      else
	if (blank) fprintf(stderr,"OK, device is blank!\n");
    } else { /* PICTOOL */
      if (chip_p->type != PIC) {
	fprintf(stderr,"Only Intel hex-file for eeprom's\n");
	fprintf(fout,"#Only Intel hex-file for eeprom's\n");
      }	else if (chip_p->extraflags&FL_PIC12SERIES) {
	fprintf(stderr,"No pictool format for PIC 12c5XX\n");
	fprintf(stdout,"#No pictool format for PIC 12c5XX\n");
      } else {
	time(&now);
	fprintf(fout,"# pictools format dump file\n# created by %s on %s",
		argv[0], ctime(&now));
	if (id || fuses) dumpCfg(fout, id,fuses);
	if (data) dumpData(fout, 0, 64);
	if (prog) dumpProg(fout, 0, last_addr);
      }
    }
    if (fout!=stdout && fout!=NULL) fclose(fout);

    progShutdown();
    
#ifdef __MSDOS__
    exit(0);
#endif
    return 0;
}

void dumpProg(FILE *fout, WORD min_addr, WORD max_addr) {
    int pic_addr=0;
    int buf_count;

    power_and_reset();
    fprintf(fout,"A%04x\n", min_addr);

    for (pic_addr=0; pic_addr < min_addr; pic_addr++)
	incAddr();

    for (buf_count = 0 ; pic_addr < max_addr ; pic_addr++) {
	buf[buf_count ++] = readProg();
	if (buf_count >= 8) {
	   dump_buf(fout,buf_count);
	   buf_count = 0;
	}
	incAddr();
    }
    if (buf_count)
	dump_buf(fout,buf_count);
}


void dumpData(FILE *fout, WORD min_addr, WORD max_addr) {
    int pic_addr;
    int buf_count;

    power_and_reset();
    fprintf(fout,"B%04x\n", min_addr);

    for (pic_addr=0; pic_addr < min_addr; pic_addr++)
	incAddr();

    for (buf_count = 0 ; pic_addr < max_addr ; pic_addr++) {
	buf[buf_count ++] = readData();
	if (buf_count >= 8) {
	   dump_buf(fout,buf_count);
	   buf_count = 0;
	}
	incAddr();
    }
    if (buf_count)
	dump_buf(fout,buf_count);
}

char *xtal_names[] = {
    "LP oscillator",
    "XT Oscillator",
    "HS Oscillator",
    "RC Oscillator"
};

void dumpCfg(FILE *fout, short pid, short pfuses)
{
    unsigned int id[8], fuses;
    int i;

    power_and_reset();

    fprintf(fout, "T84  # I can only understand '84s\n");

    /* dummy load configuration command to get to cfg memory */
    loadConfiguration(0x3FFF);
    for (i=0; i<7; i++) {
	if (i<4)
	    id[i] = readProg();
	else if (i<=6)  id[i] = readProg();
	incAddr();
    }
    fuses = readProg();

    if (pid) {
      fprintf(fout, "I%04x %04x %04x %04x  # id locations\n",
	      id[0], id[1], id[2], id[3]);
    }
    fprintf(fout, "# device id (0x2004-7) : %04x %04x %04x fuses:%04x\n",
	    id[4],id[5],id[6],fuses);

    if (pfuses) {
      fprintf(fout,"%s\n%s\n%s\nC%d 0 # %s\n",
	      fuses & 0x10 ?
	      "P1 # Code protection off" : "P0 # Code protection on",
	      fuses & 0x08 ?
	      "U1 # Power-Up Timer Enabled" : "U0 # Power-Up Timer disabled",
	      fuses & 0x04 ?
	      "W1 # Watchdog Enabled" : "W0 # Watchdog Disabled",
	      fuses & 0x03, xtal_names[fuses & 3]
	      );
    }
}


static
void notBlank(const char *s, int addr)
{
    fprintf(stderr,"Device not blank (%s: 0x%04X)\n",s,addr);
    blank=0;
}

void dumphexCfg12(FILE *fout, unsigned wid, unsigned wfuse, pic_instr_t fuses)
{
    pic_instr_t id[4];
    int i;

    if (format==BLANK_CHECK && !blank) return;

    for (i=0; i<4; i++) {
	id[i] = (pic_instr_t) readProg();
	incAddr();
    }
    if (format==BLANK_CHECK) {
       if (wid && (id[0] & id[1] & id[2] & id[3] & 0xfff)!=0xFFF) {
	  notBlank("ID",chip_p->prog_size);
	  return;
	}
	if (wfuse && (0xfff&fuses)!=0xFFF) {
	  notBlank("Fuses",0xfff);
	  return;
	}
    }

    if (wid)   write_hex_record(fout, 4, chip_p->prog_size, &id[0], format);
    if (wfuse) write_hex_record(fout, 1, 0xfff, &fuses, format);
}

void dumphexCfg16(FILE *fout,unsigned wid, unsigned wfuse)
{
    pic_instr_t fuses, id[4];
    int i;

    if (format==BLANK_CHECK && !blank) return;

    power_and_reset();

    /* dummy load configuration command to get to cfg memory */
    loadConfiguration(0x3FFF);
    for (i=0; i<7; i++) {
	if (i<4)
	    id[i] = (pic_instr_t) readProg();
	incAddr();
    }
    fuses = (pic_instr_t) readProg();

    if (format==BLANK_CHECK) {
       if (wid && (id[0] & id[1] & id[2] & id[3] & 0xfff)!=0xFFF) {
	  notBlank("ID",picid_addr);
	  return;
	}
	if (wfuse && (0xfff&fuses)!=0xFFF) {
	  notBlank("Fuses",fuse_addr);
	  return;
	}
    } 
   
    if (wid)   write_hex_record(fout, 4, fuse_addr, &id[0], format);
    if (wfuse) write_hex_record(fout, 1, picid_addr, &fuses, format);
}

pic_instr_t dumphexProg(FILE *fout, WORD min_addr, WORD max_addr, BOOL wreset)
{
    int pic_addr;
    int buf_count,beg_addr;
    pic_instr_t lastword = 0xffff;

    if (wreset) power_and_reset();

    for (pic_addr=0; pic_addr < min_addr; pic_addr++)
	incAddr();

    beg_addr=pic_addr;
    for (buf_count = 0 ; pic_addr < max_addr ; pic_addr++) {
	buf[buf_count ++] = lastword = readProg();
	if (format==BLANK_CHECK) {
	   if ((0xfff&buf[buf_count-1])!=0xFFF &&
		!(chip_p->extraflags & FL_PIC12SERIES &&
		  pic_addr==chip_p->prog_size-1)) {
	      notBlank("Program",pic_addr);
	      for ( ; pic_addr < max_addr-1 ; pic_addr++) incAddr();
	      lastword = readProg();
	      incAddr();
	      return lastword;
	   }
	}

	if (buf_count >= 8) {
	   write_hex_record(fout, buf_count, beg_addr, buf, format);
	   beg_addr +=buf_count;
	   buf_count = 0;
	}

	incAddr();
    }
    if (buf_count)
           write_hex_record(fout, buf_count, beg_addr, buf, format);

    return lastword;
}


void dumphexData(FILE *fout, WORD min_addr)
{
    int pic_addr;
    int buf_count,beg_addr;

    if (format==BLANK_CHECK && !blank) return;
    if (min_addr>=chip_p->eeprom_size) return;

    power_and_reset();

    for (pic_addr=0; pic_addr < min_addr; pic_addr++)
	incAddr();

    beg_addr=pic_addr+data_addr;
    for (buf_count = 0 ; pic_addr < chip_p->eeprom_size ; pic_addr++) {
	buf[buf_count ++] = readData() & 0xFF; /* data eeprom only 8 bit */
	if (format==BLANK_CHECK) {
	   if (buf[buf_count-1]!=0xFF) {
	      notBlank("Data",pic_addr);
	      return;
	   }
	}

	if (buf_count >= 8) {
	   write_hex_record(fout, buf_count, beg_addr, buf, format);
	   beg_addr +=buf_count;
	   buf_count = 0;
	}

	incAddr();
    }
    if (buf_count)
           write_hex_record(fout, buf_count, beg_addr, buf, format);
}


FILE *shiftFile(const char *what, const char *mode, FILE *defaultfp)
{
    FILE *fp;
    extern char *strerror();

    if ((optarg==NULL) ||  !*optarg) {
	usage(1,"arglist ends abruptly");
    }

    if (defaultfp && !strcmp(optarg,"-")) fp=defaultfp;
    else {
      fp = fopen(optarg, mode);
      if (!fp) {
	char txt[128];
	sprintf(txt, "can't open %s %s: %s",
		what, optarg, strerror(errno));
	usage(2,txt);
      }
    }
    return fp;
}
