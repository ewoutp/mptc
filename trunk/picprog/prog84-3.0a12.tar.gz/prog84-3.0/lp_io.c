/*** (C) 1994-> Wim Lewis and others (Credits file)
 ***  lp_io.c

   buffered parallel-port I/O routines. These lie on top of the
   "asm IN/OUT" analogues in io_ports.c. For convenience, they define
   "bit indicators" which pack the register of a bit, its offset
   in the byte, and whether it's inverted or not into an int.

   There are two pieces of code in this file. The first part does simple
   buffered bitwise I/O:

       lpb_write(lpb, bit, val)
       val = lpb_test(lpb, bit)
         write to and read the bit indicated by 'bit' in the buffer pointed
         to by lpb.

       lpb_flush(lpb)         writes out the data and control bytes
       lpb_refresh(lpb)       reads in the status byte

 ***
 ***/


#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h> /* for strtoul() */

#include "io_ports.h"
#include "prog84.h"

#ifdef __MSDOS__
#include "dosutil.h"
#endif

/* This turns on debugging output from lpb_cfg_read */
/* #define LPBDEBUG  */

void lpb_write(struct lp_io *lpb, int bit, int val)
{
    int mask = 1 << (bit & BI_OFFSET);
    int idx= (bit & BI_TYPE) >> BI_TYPE_SHIFT;
    if (bit & BI_INVERSE)
	val = !val;
    if (val)
	lpb->wanted[ idx ] |= mask;
    else
	lpb->wanted[ idx ] &= ~mask;
}

int lpb_test(struct lp_io *lpb, int bit)
{
    int mask = 1 << (bit & BI_OFFSET);
    if (lpb->last[ (bit & BI_TYPE) >> BI_TYPE_SHIFT ] & mask)
	return (bit & BI_INVERSE)? 0 : 1;
    else
	return (bit & BI_INVERSE)? 1 : 0;
}

#if 0
void lpb_flush(struct lp_io *lpb)
{
    int i, m=1;
    for (i=0; i<lpb->size; i++) /* gratuitous loop construct */ {
	if((lpb->wanted[i] != lpb->last[i])) {
	    out_byte(lpb->base + i, (unsigned char)(lpb->wanted[i]));
	    /* printf(".\b"); fflush(stdout); */
	    lpb->last[i] = lpb->wanted[i];
	}
	m += m; // shift left 1
    }
}
#endif

void lpb_flush(struct lp_io *lpb)
{
    int i;
    for (i=0; i<lpb->io_usage.count; i++) {
	if((lpb->io_usage.flags[i].writebits != 0) &&
	   (lpb->wanted[i] != lpb->last[i])) {
	    out_byte(lpb->io_usage.base + i, (unsigned char)(lpb->wanted[i]));
	    /* printf(".\b"); fflush(stdout); */
	    lpb->last[i] = lpb->wanted[i];
	}
    }
}

#if 0
void lpb_refresh(struct lp_io *lpb) {
    /* printf(".\b"); fflush(stdout); */
	lpb->last[1] = in_byte(lpb->base + 1);
	lpb->last[6] = in_byte(lpb->base + 6);
}

void lpb_refresh(struct lp_io *lpb) {
    /* printf(".\b"); fflush(stdout); */
    //fprintf(stderr,"%02x ",lpb->ports_in_use);
    //	SLEEP100ns(1);
    if (lpb->ports_in_use & 0x02) {
	lpb->last[1] = in_byte(lpb->base + 1);
    }
    if (lpb->ports_in_use & 0x40) {
	lpb->last[6] = in_byte(lpb->base + 6);
    }
}
#endif

void lpb_refresh(struct lp_io *lpb)
{
    int i, b;
    for (i=0; i<lpb->io_usage.count; i++) {
	if(lpb->io_usage.flags[i].readbits != 0) {
	  b = in_byte(lpb->io_usage.base + i);
	  lpb->last[i] =
	    ( lpb->last[i] & ~(lpb->io_usage.flags[i].readbits) ) |
	    ( b            &  (lpb->io_usage.flags[i].readbits) );
	}
    }
}

void lpb_open(struct lp_io *lpb)
{
#ifdef HAVE_USB
  if (lpb->io_usage.hw_type == iot_awusb) {
    open_usb(&(lpb->io_usage));
    return;
  }
#endif

#ifdef HAVE_PCIO
  /* TODO: fancier open */
  open_io(&(lpb->io_usage));
#else
  fprintf(stderr, "Unsupported type of IO device.\n");
#endif
}

void lpb_close(struct lp_io *lpb)
{
#ifdef HAVE_USB
  if (lpb->io_usage.hw_type == iot_awusb) {
    close_usb(&(lpb->io_usage));
    return;
  }
#endif

#ifdef HAVE_PCIO
  close_io();
#else
  fprintf(stderr, "Unsupported type of IO device.\n");
#endif
}

void lpb_set_extra_delay(struct lp_io_usage *lpu)
{
    int i;
    /* extra reads to slow down I/O for flaky hardware. or something. */
    for(i = 0; i < MAX_PORT_COUNT; i++)
      lpu->flags[i].readbits |= 0x000;
}


